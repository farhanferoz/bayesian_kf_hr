import os
import logging
import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
from typing import List
from market_data_utils.contract_spec_utils import DataSource, PriceType, MarketDataFields, get_trade_day_timezone_duration_hrs_and_offset_hrs, read_contract_specs, change_timezone
from market_data_utils.general_utils import setup_logger

from cointegration.simulation import plot_time_series


class FuturesDataForCointegration:
    def __init__(
        self,
        data_source: DataSource,
        data_dir: str,
        contract_specs_file_path: str,
        input_bin_size_min: int,
        output_bin_size_min: int,
        target_time_zone: str,
        instrument_y: str,
        instrument_x: List[str],
        start_date: dt.datetime.date,
        end_date: dt.datetime.date,
        price_type: PriceType,
        use_returns: bool,
    ):
        self.data_source = data_source
        self.data_dir = os.path.join(data_dir, self.data_source.label, "minute")
        self.input_bin_size_min = input_bin_size_min
        self.output_bin_size_min = output_bin_size_min
        self.target_time_zone = target_time_zone
        self.instrument_y = instrument_y
        self.instrument_x = instrument_x
        self.start_date = start_date
        self.end_date = end_date
        self.price_type = price_type
        self.use_returns = use_returns

        assert output_bin_size_min >= input_bin_size_min

        self.max_return = 0.15

        setup_logger(debug=True)
        self.contract_specs_df = read_contract_specs(contract_specs_file_path=contract_specs_file_path)

        self.df_prices = pd.DataFrame()

    def read_data(self) -> None:
        for instrument in [self.instrument_y] + self.instrument_x:
            df = self.read_futures_data(instrument=instrument)
            self.df_prices = pd.concat([self.df_prices, df], axis=1)
        self.df_prices.dropna(inplace=True)

    def get_futures_data_file_name(self, instrument: str, year: int) -> str:
        return os.path.join(self.data_dir, instrument, f"{instrument}_{self.price_type.file_id}_{year}.csv.gz")

    @staticmethod
    def _bin_data(df: pd.DataFrame, output_bin_size_min: int, duration_hrs: float, price_col: str) -> pd.DataFrame:
        bin_direction = "left" if (output_bin_size_min == 24 * 60) else "right"
        agg_dict = {price_col: "last"}
        df_binned = df.resample(f"{output_bin_size_min}min", label=bin_direction).agg(agg_dict)
        df_binned = df_binned[df_binned.index.dayofweek < 5]
        if output_bin_size_min == 24 * 60:
            df_binned.dropna(inplace=True)
        else:
            # set the data for intervals with no quotes to be the same as the last quote
            time_offset_from_start_of_day_col = "time_offset_from_start_of_day"
            df_binned[time_offset_from_start_of_day_col] = df_binned.index.hour + df_binned.index.minute / 60.0
            df_binned.loc[(df_binned[time_offset_from_start_of_day_col] == 0) | (df_binned[time_offset_from_start_of_day_col] > duration_hrs), price_col] = 0
            df_binned[price_col] = df_binned[price_col].fillna(method="pad")
            df_binned = df_binned.loc[df_binned[price_col] > 0]
            df_binned.drop(columns=[time_offset_from_start_of_day_col], inplace=True)
        return df_binned

    def read_futures_data(self, instrument: str) -> pd.DataFrame:
        instrument_info = self.contract_specs_df.loc[instrument]
        instrument_time_zone, duration_hrs, offset_hrs = get_trade_day_timezone_duration_hrs_and_offset_hrs(instrument_info=instrument_info)

        df_data = pd.DataFrame()
        st_date = self.start_date
        while st_date <= self.end_date:
            ed_date = min(self.end_date, st_date.replace(day=1, month=1) + relativedelta(years=1) - relativedelta(days=1))
            file_path = self.get_futures_data_file_name(instrument=instrument, year=st_date.year)
            logging.info(f"Reading file: {file_path} ...")
            df = pd.read_csv(file_path)
            logging.info(f"Read {len(df)} rows.")
            df[MarketDataFields.timestamp.value] = pd.to_datetime(df[MarketDataFields.timestamp.value])
            change_timezone(df=df, timestamp_col=MarketDataFields.timestamp.value, input_timezone=self.data_source.data_time_zone, output_timezone=instrument_time_zone)
            df = df.loc[(df[MarketDataFields.timestamp.value].dt.date >= st_date) & (df[MarketDataFields.timestamp.value].dt.date <= ed_date)]
            df.set_index(MarketDataFields.timestamp.value, inplace=True)
            if self.price_type == PriceType.TRADE:
                df[instrument] = df[MarketDataFields.close_price.value]
            elif self.price_type == PriceType.MID:
                df[instrument] = (df[MarketDataFields.bid_close.value] + df[MarketDataFields.offer_close.value]) / 2
            else:
                raise ValueError(f"Price type {self.price_type.internal_label} is not supported.")
            df.drop(columns=[col for col in df.columns if col != instrument], inplace=True)

            # normalize times to start of trading day & timestamps to be at the start of the interval
            df.index += pd.Timedelta(days=0, hours=int(offset_hrs), minutes=int(round((offset_hrs - int(offset_hrs)) * 60)) - self.input_bin_size_min)
            # bin the data
            df = self._bin_data(df=df, output_bin_size_min=self.output_bin_size_min, duration_hrs=duration_hrs, price_col=instrument)
            # un-normalize times
            df.index += -pd.Timedelta(days=0, hours=int(offset_hrs), minutes=int(round((offset_hrs - int(offset_hrs)) * 60)))
            # change the time zone to target time zone
            df.reset_index(inplace=True)
            change_timezone(df=df, timestamp_col=MarketDataFields.timestamp.value, input_timezone=instrument_time_zone, output_timezone=self.target_time_zone)
            df.set_index(MarketDataFields.timestamp.value, inplace=True)

            df_data = pd.concat([df_data, df])
            st_date = ed_date + relativedelta(days=1)

        if self.use_returns or self.max_return < np.inf:
            df_data[MarketDataFields.rtn.value] = 1 - df_data / df_data.shift()
            if self.max_return < np.inf:
                df_data = df_data.loc[df_data[MarketDataFields.rtn.value].abs() <= self.max_return]
            if self.use_returns:
                df_data[instrument] = df_data[MarketDataFields.rtn.value]
            df_data.drop(columns=[MarketDataFields.rtn.value], inplace=True)

        return df_data


def normalize_prices(df: pd.DataFrame) -> pd.DataFrame:
    instruments = list(df.columns)
    for instrument in instruments[1:]:
        multiplier = df.iloc[0][instruments[0]] / df.iloc[0][instrument]
        df.loc[:, instrument] *= multiplier
    return df


def main() -> None:
    future_data = FuturesDataForCointegration(
        data_source=DataSource.NINJATRADER,
        data_dir=r"C:\Users\farha\PycharmProjects\Oasis\StrategyA\data",
        contract_specs_file_path=r"C:\Users\farha\PycharmProjects\Oasis\StrategyA\data\NinjaTrader\ContractSpecs.csv",
        input_bin_size_min=1,
        output_bin_size_min=10,
        target_time_zone="UTC",
        instrument_y="ZT",
        instrument_x=["FGBL"],
        start_date=dt.datetime.strptime("2018.01.01", "%Y.%m.%d").date(),
        end_date=dt.datetime.strptime("2019.12.31", "%Y.%m.%d").date(),
        price_type=PriceType.MID,
        use_returns=False,
    )
    future_data.read_data()
    plot_time_series(df=normalize_prices(df=future_data.df_prices), title="", plot_file=None, is_index_datetime=True)


if __name__ == "__main__":
    main()
