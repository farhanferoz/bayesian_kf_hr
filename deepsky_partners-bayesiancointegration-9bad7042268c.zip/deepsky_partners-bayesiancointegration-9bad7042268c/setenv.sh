export LD_LIBRARY_PATH=/mnt/c/Users/farha/PycharmProjects/MultiNest/MultiNest_v3.12_CMake/multinest/lib:$LD_LIBRARY_PATH
export PYTHONPATH=$PYTHONPATH:/mnt/c/Users/farha/PycharmProjects/Oasis/BayesianCointegration/
