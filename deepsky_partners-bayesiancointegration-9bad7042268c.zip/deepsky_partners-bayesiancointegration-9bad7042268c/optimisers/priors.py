import numpy as np
from scipy.special import erfinv
import abc


def from_cube_to_param_for_uniform_in_log_prior(cube_value: float, min_value: float, max_value: float) -> float:
    increment = 0.01 - min_value if min_value <= 0.0 else 0.0
    shifted_min_value = min_value + increment
    shifted_max_value = max_value + increment
    theta = np.exp(np.log(shifted_min_value) + np.log(shifted_max_value / shifted_min_value) * cube_value) - increment
    return theta


class Prior(metaclass=abc.ABCMeta):
    def __init__(self, min_value: float = -np.inf, max_value: float = np.inf, round_to_nearest: float = 0):
        self.min_value = min_value
        self.max_value = max_value
        self.round_to_nearest = round_to_nearest
        self.is_delta_prior = self.min_value == self.max_value
        assert self.min_value <= self.max_value

    def round_value_to_nearest(self, theta: float) -> float:
        if self.round_to_nearest > 0:
            theta = min(self.max_value, max(self.min_value, round(theta / self.round_to_nearest) * self.round_to_nearest))
        return theta

    @abc.abstractmethod
    def cube_to_param(self, cube_value: float) -> float:
        raise NotImplementedError()


class DeltaPrior(Prior):
    def __init__(self, fixed_value: float):
        super().__init__(min_value=fixed_value, max_value=fixed_value)

    def cube_to_param(self, cube_value: float) -> float:
        return self.min_value


class UniformPrior(Prior):
    def __init__(self, min_value: float, max_value: float, round_to_nearest: float = 0):
        super().__init__(min_value=min_value, max_value=max_value, round_to_nearest=round_to_nearest)

    def cube_to_param(self, cube_value: float) -> float:
        theta = self.min_value + (self.max_value - self.min_value) * cube_value
        return self.round_value_to_nearest(theta=theta)


class UniformInLogPrior(Prior):
    def __init__(self, min_value: float, max_value: float, round_to_nearest: float = 0):
        super().__init__(min_value=min_value, max_value=max_value, round_to_nearest=round_to_nearest)

    def cube_to_param(self, cube_value: float) -> float:
        return self.round_value_to_nearest(theta=from_cube_to_param_for_uniform_in_log_prior(cube_value=cube_value, min_value=self.min_value, max_value=self.max_value))


class ReflectedUniformInLogPrior(Prior):
    def __init__(self, min_value: float, max_value: float, round_to_nearest: float = 0):
        super().__init__(min_value=min_value, max_value=max_value, round_to_nearest=round_to_nearest)

    def cube_to_param(self, cube_value: float) -> float:
        theta = from_cube_to_param_for_uniform_in_log_prior(cube_value=cube_value, min_value=self.min_value, max_value=self.max_value)
        theta = self.max_value - (theta - self.min_value)
        return self.round_value_to_nearest(theta=theta)


class ZeroUnionUniformInLogPrior(Prior):
    def __init__(self, zero_prior_probability: float, non_zero_min_value: float, max_value: float, round_to_nearest: float = 0):
        super().__init__(min_value=0 if zero_prior_probability > 0 else non_zero_min_value, max_value=max_value, round_to_nearest=round_to_nearest)
        self.zero_prior_probability = zero_prior_probability
        self.non_zero_min_value = non_zero_min_value

    def cube_to_param(self, cube_value: float) -> float:
        if cube_value <= self.zero_prior_probability:
            theta = 0.0
        else:
            adjusted_cube_value = (cube_value - self.zero_prior_probability) / (1 - self.zero_prior_probability)
            theta = from_cube_to_param_for_uniform_in_log_prior(cube_value=adjusted_cube_value, min_value=self.non_zero_min_value, max_value=self.max_value)
            theta = self.round_value_to_nearest(theta=theta)
        return theta


class NormalPrior(Prior):
    def __init__(self, mu: float, sigma: float, round_to_nearest: float = 0):
        super().__init__(round_to_nearest=round_to_nearest)
        self.mu = mu
        self.sigma = sigma

    def cube_to_param(self, cube_value: float) -> float:
        theta = erfinv(2 * cube_value - 1) * self.sigma * np.sqrt(2) + self.mu
        return self.round_value_to_nearest(theta=theta)
