from pymultinest.solve import solve
import numpy as np
from functools import lru_cache
from typing import List, Optional, Any, Tuple
import sys
import os.path
import pandas as pd

from cointegration.kalman_filter_cointegration import Columns
from cointegration.utils import fix_numeric_for_infinity
from optimisers.optimiser import Optimiser, BestParameterSelectionCriterion
from cointegration.model_specifications import ModelSpecifications


class MultiNest(Optimiser):
    def __init__(
        self,
        best_parameter_selection_criterion: BestParameterSelectionCriterion,
        model_specifications: ModelSpecifications,
        outputfiles_basename: str,
        n_live_points: int = 500,
        evidence_tolerance: float = 1.0,
        sampling_efficiency: float = 0.5,
        importance_nested_sampling: bool = False,
        const_efficiency_mode: bool = False,
        multimodal: bool = True,
        use_all_params_for_mode_separation: bool = False,
        n_iter_before_update: int = 50,
        log_like_range_for_convergence: float = 0.5,
        max_log_like_calls: int = 100000,
        max_iterations: int = 10000,
        decimal_places_to_round_log_like: int = 6,
        resume: bool = True,
    ):
        """
        MultiNest optimisation
        :param best_parameter_selection_criterion: selection criterion for likelihood
        :param model_specifications: ModelParameters object
        :param outputfiles_basename: basename (with folder) for the output files from MultiNest
        :param n_live_points: no. of live points
        :param evidence_tolerance: tolerance in log evidence for convergence
        :param sampling_efficiency: target sampling efficiency
        :param importance_nested_sampling: whether to use Importance Nested Sampling
        :param const_efficiency_mode: whether to use the constant efficiency mode
        :param multimodal: whether to detect multiple modes
        :param use_all_params_for_mode_separation: if T then use all the parameters for mode separation otherwise use max of (first) 3
        :param n_iter_before_update: no. of iterations before updating output files
        :param log_like_range_for_convergence: min range in logL, with logL > 0, for convergence of MultiNest
        :param max_log_like_calls: max number of calls to loglikehood function allowed
        :param max_iterations: max number of iterations of MultiNest allowed
        :param decimal_places_to_round_log_like: no. of decimal places to round the logL values (after scaling by returns_multiplier) to be used in enrriching
        :param resume whether to resume from previous job
        """
        super().__init__(best_parameter_selection_criterion=best_parameter_selection_criterion, model_specifications=model_specifications)

        # MultiNest Parameters
        self.n_live_points = n_live_points
        self.evidence_tolerance = evidence_tolerance
        self.sampling_efficiency = sampling_efficiency
        self.importance_nested_sampling = importance_nested_sampling
        self.const_efficiency_mode = const_efficiency_mode
        self.multimodal = multimodal
        self.resume = resume
        self.n_clustering_params = self.n_dims if use_all_params_for_mode_separation else min(3, self.n_dims)
        self.n_iter_before_update = n_iter_before_update
        self.impose_objective_function_value_pnl_correspondence = True
        self.log_like_range_for_convergence = log_like_range_for_convergence
        self.max_iterations = max_iterations

        self.max_log_like_calls = max_log_like_calls
        self.min_log_like_calls_for_early_convergence = 10000
        self.n_log_like_calls = 0

        self.decimal_places_to_round_log_like = decimal_places_to_round_log_like
        self.max_log_like_fraction_to_retain = 0.7
        self.outputfiles_basename = outputfiles_basename
        self.phys_live_enriched_file: str = f"{self.outputfiles_basename}phys_live_enriched_points.csv"
        self.best_fit_pred_data_file: str = f"{self.outputfiles_basename}best_fit_pred_data.csv"

        # has MultiNest converged
        self.done = False
        self.check_if_converged_at_start()

    def check_if_converged_at_start(self) -> None:
        """
        check if the job has already converged at start-up, i.e. if it is getting resumed & has converged already
        :return:
        """
        if self.resume and (self.max_log_like_calls > 0 or self.max_iterations > 0):
            resume_file = "%sresume.dat" % self.outputfiles_basename
            if os.path.exists(resume_file):
                file_handle = open(resume_file, "r")
                lines: List[str] = file_handle.readlines()
                if len(lines) > 1:
                    file_handle.close()
                    vals: List[int] = lines[1].split()
                    n_iterations = int(vals[0])
                    self.n_log_like_calls = int(vals[1])

                    phys_live_file = "%sphys_live.points" % self.outputfiles_basename
                    log_like = np.loadtxt(phys_live_file)[:, -2]
                    log_like_range = self._get_log_like_range(log_like=log_like)

                    self.check_if_converged(n_iterations=n_iterations, log_like_range_for_convergence=log_like_range)

    def check_if_converged(self, n_iterations: Optional[int] = None, log_like_range_for_convergence: Optional[float] = None) -> None:
        """
        check if the convergence criterion has reached
        :param n_iterations: number of iterations done
        :param log_like_range_for_convergence: range of log like values
        :return:
        """
        if (self.max_log_like_calls > 0) and (self.n_log_like_calls >= self.max_log_like_calls):
            self.done = True
        elif (self.max_iterations > 0) and (n_iterations is not None) and (n_iterations >= self.max_iterations):
            self.done = True
        elif (
            (self.n_log_like_calls >= self.min_log_like_calls_for_early_convergence)
            and (self.log_like_range_for_convergence > 0)
            and (log_like_range_for_convergence is not None)
            and (log_like_range_for_convergence <= self.log_like_range_for_convergence)
        ):
            self.done = True

    def prior(self, cube: np.ndarray) -> np.ndarray:
        """
        convert the parameters in unit hypercube according to prior
        :param cube: parameters in unit hypercube having dimension self.n_dim
        :return: an array with dimension self.n_params that has the values of unit hypercube parameters converted according to prior
        """
        k: int = 0
        for i in range(self.n_params):
            self.current_parameter_values[i] = self.priors[i].cube_to_param(cube_value=cube[k])
            if not self.priors[i].is_delta_prior:
                cube[k] = self.current_parameter_values[i]
                k += 1
        return self.current_parameter_values

    def _enrich_phys_live_points(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        calculate additional statistics for the live points
        :param df: dataframe with parameter values followed by logL
        :return:
            1. enriched dataframe with first n columns being the same as input dataframe, followed by columns with additional statistics
            2. dataframe with prediction data for the best fit point
        """
        df_enriched = df.loc[:, self.parameter_names + [Columns.objective_function_value.value]].copy()
        additional_cols = self.model_specifications.kf_cointegration.pnl_based_statistics.keys()
        for col in additional_cols:
            df_enriched[col] = 0.0
        df_enriched.sort_values(by=Columns.objective_function_value.value, ascending=False, inplace=True)
        df_enriched.reset_index(drop=True, inplace=True)
        df_best_fit_pred_data = pd.DataFrame()
        for row in df_enriched.itertuples():
            index = row[0]
            self._set_model_parameters(params=fix_numeric_for_infinity(np.array(row[1:])))
            if (
                self.impose_objective_function_value_pnl_correspondence
                and index > 0
                and df_enriched.loc[index, Columns.objective_function_value.value] == df_enriched.loc[index - 1, Columns.objective_function_value.value]
            ):
                for col in additional_cols:
                    df_enriched.loc[index, col] = df_enriched.loc[index - 1, col]
            else:
                self.model_specifications.kf_cointegration.apply(calculate_loglike=True, calculate_pnl=True)
                if index == 0:
                    df_best_fit_pred_data = self.model_specifications.kf_cointegration.get_prediction_data()
                for col in additional_cols:
                    df_enriched.loc[index, col] = self.model_specifications.kf_cointegration.pnl_based_statistics[col]
                self._check_for_best_utility(
                    utility_value=self.model_specifications.kf_cointegration.get_utility_value(best_parameter_selection_criterion=self.best_parameter_selection_criterion)
                )
        return df_enriched, df_best_fit_pred_data

    @lru_cache(maxsize=10000)
    def cached_likelihood(self, arr_tostring_np: bytes) -> float:
        return self.log_likelihood()

    @staticmethod
    def _get_log_like_range(log_like: np.ndarray, positive_log_like_fraction: float = 0.8, max_log_like: Optional[float] = None) -> float:
        """
        find the range of logL values. if ratio of positive logL values is less than positive_log_like_fraction then range is inf
        :param log_like: array with logL values
        :param positive_log_like_fraction: if the ratio of positive logL values is less than this fraction then range is inf
        :param max_log_like: max logL if already calculated
        :return: range of logL values
        """
        log_like_range = np.inf
        if len(log_like[log_like > 0]) / len(log_like) >= positive_log_like_fraction:
            if max_log_like is None:
                max_log_like = np.max(log_like)
            log_like_range = max_log_like - np.min(log_like)
        return log_like_range

    def dumper(
        self,
        n_samples: int,
        n_live: int,
        n_par: int,
        phys_live: np.ndarray,
        posterior: np.ndarray,
        param_constr: np.ndarray,
        max_log_like: float,
        log_z: float,
        log_z_err: float,
        nullcontext: Any,
    ) -> None:
        if self.log_like_range_for_convergence > 0:
            log_like_range = self._get_log_like_range(log_like=phys_live[:, -1], max_log_like=max_log_like)
            self.check_if_converged(log_like_range_for_convergence=log_like_range)

    def _sort_enriched_points_by_utility(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        sort the enriched live points according to utility values in descending order
        :param df: input dataframe
        :return: sorted dataframe
        """
        df.sort_values(by=self.best_parameter_selection_col, inplace=True, ascending=False)
        df.reset_index(drop=True, inplace=True)
        return df

    def set_parameters_with_best_utility_after_optimisation(self) -> bool:
        """
        Set the best parameters according to best parameter selection criterion with re-running the optimisation. This is for optimisation methods that keep a record of handful
        of best points & can be useful when a utility function different from the one used during optimisation, needs to be applied to the best points found.
        :return: True if parameters with best utility set, False otherwise
        """
        done = False
        if os.path.exists(self.phys_live_enriched_file):
            df = pd.read_csv(self.phys_live_enriched_file, index_col=0)
            df = self._sort_enriched_points_by_utility(df)
            if not df.empty:
                self._set_model_parameters(params=fix_numeric_for_infinity(df.iloc[0].values[: self.n_params]))
                self._check_for_best_utility(utility_value=df.iloc[0][self.best_parameter_selection_col], initialise=True)
            done = True
        return done

    def _get_points_to_enrich(self) -> pd.DataFrame:
        """
        get points to be enriched
        :return: dataframe with points to be enriched
        """
        points_file = f"{self.outputfiles_basename}.txt"
        df = pd.read_csv(
            points_file, delim_whitespace=True, header=None, usecols=range(1, self.n_params + 2), names=[Columns.objective_function_value.value] + self.parameter_names
        )
        df[Columns.objective_function_value.value] /= -2
        df.sort_values(by=Columns.objective_function_value.value, ascending=False, inplace=True)
        max_log_like = df[Columns.objective_function_value.value].max()
        df = df.loc[df[Columns.objective_function_value.value] >= max_log_like - abs(max_log_like) * (1 - self.max_log_like_fraction_to_retain)]
        if len(df) > self.n_live_points:
            rounded_log_like_lab = f"rounded_{Columns.objective_function_value.value}"
            df[rounded_log_like_lab] = df[Columns.objective_function_value.value].round(self.decimal_places_to_round_log_like)
            df.drop_duplicates(subset=[rounded_log_like_lab], keep="first", inplace=True)
            df.drop(columns=[rounded_log_like_lab], inplace=True)
            df = df.iloc[: self.n_live_points]
        return df

    def optimise(self):
        def multinest_prior(cube: np.ndarray) -> np.ndarray:
            return self.prior(cube)

        def multinest_likelihood(cube: np.ndarray) -> float:
            if self.done:
                loglike = sys.float_info.max
            else:
                self.n_log_like_calls += 1
                loglike = self.cached_likelihood(self.current_parameter_values.tostring())
                self.check_if_converged()
            return loglike

        def multinest_dumper(
            n_samples: int,
            n_live: int,
            n_par: int,
            phys_live: np.ndarray,
            posterior: np.ndarray,
            param_constr: np.ndarray,
            max_log_like: float,
            log_z: float,
            log_z_err: float,
            nullcontext: Any,
        ) -> None:
            self.dumper(n_samples, n_live, n_par, phys_live, posterior, param_constr, max_log_like, log_z, log_z_err, nullcontext)

        result = solve(
            n_dims=self.n_dims,
            n_params=self.n_params,
            n_live_points=self.n_live_points,
            evidence_tolerance=self.evidence_tolerance,
            sampling_efficiency=self.sampling_efficiency,
            importance_nested_sampling=self.importance_nested_sampling,
            const_efficiency_mode=self.const_efficiency_mode,
            multimodal=self.multimodal,
            n_clustering_params=self.n_clustering_params,
            n_iter_before_update=self.n_iter_before_update,
            outputfiles_basename=self.outputfiles_basename,
            LogLikelihood=multinest_likelihood,
            Prior=multinest_prior,
            dump_callback=multinest_dumper,
            seed=-1,
            max_iter=self.max_iterations,
            resume=self.resume,
            verbose=True,
        )

        print(self.cached_likelihood.cache_info())

        # get the last set of live points & enrich them
        if (not self.resume) or (not self.set_parameters_with_best_utility_after_optimisation()):
            df_highest_pnl_points = self._get_points_to_enrich()
            df_enriched, df_best_fit_pred_data = self._enrich_phys_live_points(df_highest_pnl_points)
            df_enriched = self._sort_enriched_points_by_utility(df_enriched)
            df_enriched.to_csv(self.phys_live_enriched_file)
            df_best_fit_pred_data.to_csv(self.best_fit_pred_data_file)
