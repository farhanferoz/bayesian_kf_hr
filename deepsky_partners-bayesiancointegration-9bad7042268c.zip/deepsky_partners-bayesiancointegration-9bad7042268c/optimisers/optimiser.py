import abc
from typing import Dict, Tuple, Optional
import pandas as pd
import numpy as np
from copy import deepcopy

from cointegration.kalman_filter_cointegration import BestParameterSelectionCriterion
from cointegration.model_specifications import ModelSpecifications


class Optimiser(metaclass=abc.ABCMeta):
    def __init__(self, best_parameter_selection_criterion: BestParameterSelectionCriterion, model_specifications: ModelSpecifications):
        """
        Perform optimisation
        :param best_parameter_selection_criterion: selection criterion for likelihood
        :param model_specifications: ModelParameters object
        """
        self.best_parameter_selection_criterion = best_parameter_selection_criterion
        self.model_specifications = model_specifications

        self.priors = self.model_specifications.param_priors
        self.parameter_names = self.model_specifications.param_names
        self.best_parameter_selection_col = self.model_specifications.kf_cointegration.get_col_for_best_parameter_selection_criterion(
            best_parameter_selection_criterion=self.best_parameter_selection_criterion
        )

        self.n_params = len(self.priors)
        self.n_dims = self._get_ndim()
        self.current_parameter_values: np.ndarray = np.zeros(self.n_params)
        self.best_utility = -np.inf
        self.best_parameters: Optional[np.ndarray] = None

    @abc.abstractmethod
    def optimise(self):
        raise NotImplementedError

    def _get_ndim(self) -> int:
        """
        calculate the number of parameters that don't have delta priors
        :return:
        """
        return int(np.sum([0 if prior.is_delta_prior else 1 for prior in self.priors]))

    def _check_for_best_utility(self, utility_value: float, initialise: bool = False) -> None:
        """
        check if the given utility (of the current set of strategy parameters) is the best so far & if it is then set it as best
        :param utility_value: utility value
        :param df_trades: dataframe with trades
        :param initialise: whether to initialise best utility with the input values
        :return: None
        """
        if initialise or (utility_value > self.best_utility):
            self.best_utility = utility_value
            self.best_parameters = deepcopy(self.current_parameter_values)

    def _set_model_parameters(self, params: np.array) -> None:
        self.model_specifications.set_model_params(param_values=params[: self.model_specifications.n_free_params])

    def log_likelihood(self) -> float:
        """
        calculate the log-likelihood value
        :return: log-likelihood value
        """
        self.model_specifications.set_model_params(param_values=self.current_parameter_values)
        self.model_specifications.kf_cointegration.apply(calculate_loglike=False, calculate_pnl=False)
        return self.model_specifications.kf_cointegration.objective_function_value
