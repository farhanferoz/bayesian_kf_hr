import abc
import os
import numpy as np
import pandas as pd
from typing import List, Optional, Tuple
from bokeh.plotting import figure, show, save, output_file
import itertools
from bokeh.palettes import Category10
from enum import Enum

from cointegration.residual_models import ResidualModelId


class Columns(Enum):
    trend = "trend"
    diff = "diff"
    time_series = "time_series"
    beta = "beta"
    ornstein_ublenbeck_eps = "ornstein_ublenbeck_eps"
    ornstein_ublenbeck_half_life = "ornstein_ublenbeck_half_life"
    timestamp = "timestamp"
    residual = "residual"
    half_life = "half_life"
    garch_sigma = "garch_sigma"


class ResidualModelSpecification(metaclass=abc.ABCMeta):
    def __init__(self, residual_model_id: ResidualModelId):
        self.residual_model_id = residual_model_id

    @staticmethod
    def simulate_gaussian_random_time_series(n_time_steps: int, initial_value: float, sigma: float) -> np.array:
        y = np.random.normal(0, sigma, n_time_steps)
        if initial_value != 0:
            y = np.cumsum(y) + initial_value
        return y

    @staticmethod
    def simulate_sinusoid(n_time_steps: int, mean_value: float, period: float, max_variation_fraction: float) -> np.array:
        y = np.full(n_time_steps, mean_value, dtype=float) if period == 0 else mean_value * (1 + max_variation_fraction * np.sin(np.arange(n_time_steps) * 2 * np.pi / period))
        return y

    @abc.abstractmethod
    def simulate(self, n_time_steps: int, dt: float) -> pd.DataFrame:
        raise NotImplementedError()

    @staticmethod
    def _initialise_df(n_time_steps: int) -> pd.DataFrame:
        df = pd.DataFrame(index=range(n_time_steps))
        df.index.name = Columns.timestamp.value
        return df


class OrnsteinUhlenbeckSpecification(ResidualModelSpecification):
    def __init__(
        self,
        ornstein_uhlenbeck_half_life_mean: float,
        ornstein_uhlenbeck_half_life_period: float,
        ornstein_uhlenbeck_half_life_max_variation_fraction: float,
        white_noise_sigma: float,
        ornstein_uhlenbeck_target: float = 0.0,
    ):
        super().__init__(residual_model_id=ResidualModelId.ORNSTEIN_UHLENBECK)
        self.ornstein_uhlenbeck_half_life_mean = ornstein_uhlenbeck_half_life_mean
        self.ornstein_uhlenbeck_half_life_period = ornstein_uhlenbeck_half_life_period
        self.ornstein_uhlenbeck_half_life_max_variation_fraction = ornstein_uhlenbeck_half_life_max_variation_fraction
        self.white_noise_sigma = white_noise_sigma
        self.ornstein_uhlenbeck_target = ornstein_uhlenbeck_target

    def simulate(self, n_time_steps: int, dt: float) -> pd.DataFrame:
        y = self.simulate_gaussian_random_time_series(n_time_steps=n_time_steps, initial_value=0, sigma=self.white_noise_sigma * np.sqrt(dt))
        if not np.isinf(self.ornstein_uhlenbeck_half_life_mean):
            half_lives = self.simulate_sinusoid(
                n_time_steps=n_time_steps,
                mean_value=self.ornstein_uhlenbeck_half_life_mean,
                period=self.ornstein_uhlenbeck_half_life_period,
                max_variation_fraction=self.ornstein_uhlenbeck_half_life_max_variation_fraction,
            )
            for i in range(1, n_time_steps):
                decay_rate = np.log(2) / half_lives[i]
                y[i] += y[i - 1] + decay_rate * (self.ornstein_uhlenbeck_target - y[i - 1]) * dt
        else:
            half_lives = np.full(n_time_steps, np.inf)
        df = self._initialise_df(n_time_steps=n_time_steps)
        df[Columns.residual.value] = y
        df[Columns.half_life.value] = half_lives
        return df


class GarchSpecification(ResidualModelSpecification):
    def __init__(
        self,
        residual_model_id: ResidualModelId,
        garch_alphas: np.array,
        garch_betas: np.array,
        white_noise_sigma: float,
    ):
        super().__init__(residual_model_id=residual_model_id)
        assert self.residual_model_id in [ResidualModelId.GARCH00, ResidualModelId.GARCH11]
        assert len(garch_alphas) == self.residual_model_id.garch_order_q
        assert len(garch_betas) == self.residual_model_id.garch_order_p
        self.garch_alphas = garch_alphas
        self.garch_betas = garch_betas
        self.white_noise_sigma = white_noise_sigma

    def _calculate_variance(self, dt: float, last_sigmas: np.array, last_errors: np.array) -> float:
        assert len(last_sigmas) == self.residual_model_id.garch_order_p
        assert len(last_errors) == self.residual_model_id.garch_order_q
        variance = (self.white_noise_sigma**2) * dt
        if self.residual_model_id.garch_order_p > 0:
            variance += np.dot(self.garch_betas, np.square(last_sigmas))
        if self.residual_model_id.garch_order_q > 0:
            variance += np.dot(self.garch_alphas, np.square(last_errors))
        return variance

    def simulate(self, n_time_steps: int, dt: float) -> pd.DataFrame:
        y = self.simulate_gaussian_random_time_series(n_time_steps=n_time_steps, initial_value=0, sigma=self.white_noise_sigma * np.sqrt(dt))
        garch_sigmas = np.zeros(n_time_steps)
        if self.residual_model_id.garch_order_p + self.residual_model_id.garch_order_q > 0:
            last_sigmas = np.zeros(self.residual_model_id.garch_order_p)
            last_errors = np.zeros(self.residual_model_id.garch_order_q)
            for i in range(n_time_steps):
                garch_sigmas[i] = np.sqrt(self._calculate_variance(dt=dt, last_sigmas=last_sigmas, last_errors=last_errors))
                y[i] += self.simulate_gaussian_random_time_series(n_time_steps=1, initial_value=0, sigma=garch_sigmas[i])[0]
                if self.residual_model_id.garch_order_p > 0:
                    last_sigmas[:-1] = last_sigmas[1:]
                    last_sigmas[-1] = garch_sigmas[i]
                if self.residual_model_id.garch_order_q > 0:
                    last_errors[:-1] = last_errors[1:]
                    last_errors[-1] = y[i]
        df = self._initialise_df(n_time_steps=n_time_steps)
        df[Columns.residual.value] = y
        df[Columns.garch_sigma.value] = garch_sigmas
        return df


class Simulate:
    def __init__(
        self,
        n_time_steps: int,
        x_0: float,
        x_sigma: float,
        beta_0_mean: float,
        beta_0_sigma: float,
        beta_1_mean: float,
        beta_1_period: float,
        beta_1_max_variation_fraction: float,
        residual_model_specifications: ResidualModelSpecification,
        random_seed: Optional[int] = 1,
    ):
        self.n_time_steps = n_time_steps
        self.x_0 = x_0
        self.x_sigma = x_sigma
        self.beta_0_mean = beta_0_mean
        self.beta_0_sigma = beta_0_sigma
        self.beta_1_mean = beta_1_mean
        self.beta_1_period = beta_1_period
        self.beta_1_max_variation_fraction = beta_1_max_variation_fraction
        self.residual_model_specifications = residual_model_specifications
        if random_seed is not None:
            np.random.seed(random_seed)
        self.dt = 1
        self.df = self.simulate()

    def simulate_dependent_time_series(
        self, independent_time_series: np.array, beta_0_mean: float, beta_0_sigma: float, beta_1_mean: float, beta_1_period: float
    ) -> Tuple[np.array, np.array, np.array]:
        n = len(independent_time_series)
        beta_0 = np.random.normal(beta_0_mean, beta_0_sigma, n)
        beta_1 = self.residual_model_specifications.simulate_sinusoid(
            n_time_steps=n, mean_value=beta_1_mean, period=beta_1_period, max_variation_fraction=self.beta_1_max_variation_fraction
        )
        x = beta_0 + np.multiply(independent_time_series, beta_1)
        return x, beta_0, beta_1

    def simulate(self) -> pd.DataFrame:
        x = self.residual_model_specifications.simulate_gaussian_random_time_series(n_time_steps=self.n_time_steps, initial_value=self.x_0, sigma=self.x_sigma)
        y, beta_0, beta_1 = self.simulate_dependent_time_series(
            independent_time_series=x, beta_0_mean=self.beta_0_mean, beta_0_sigma=self.beta_0_sigma, beta_1_mean=self.beta_1_mean, beta_1_period=self.beta_1_period
        )
        df = self.residual_model_specifications.simulate(n_time_steps=self.n_time_steps, dt=self.dt)
        eps = df[Columns.residual.value].values
        y += eps
        df[get_time_series_label(time_series_id=1)] = y
        df[get_time_series_label(time_series_id=2)] = x
        df[f"{Columns.beta.value} 0"] = beta_0
        df[f"{Columns.beta.value} 1"] = beta_1
        return df


def get_time_series_label(time_series_id: int) -> str:
    return f"{Columns.time_series.value}_{time_series_id}"


def plot_time_series(df: pd.DataFrame, title: Optional[str] = None, plot_file: Optional[str] = None, is_index_datetime: bool = False) -> None:
    if is_index_datetime:
        p = figure(plot_width=800, plot_height=600, x_axis_type="datetime")
    else:
        p = figure(plot_width=800, plot_height=600)
    colors = itertools.cycle(Category10[10])
    for ts_label, color in zip(df.columns, colors):
        if len(df[ts_label].dropna()) > 0:
            p.line(x=df.index, y=df[ts_label].values, color=color, alpha=0.8, legend_label=str(ts_label))
    p.legend.click_policy = "hide"
    p.legend.border_line_alpha = 0.1
    p.legend.label_text_font_size = "8pt"
    p.title.text = title
    if plot_file is not None:
        output_file(plot_file, title=title)
        save(p)
    show(p)


def simulate_non_cointegrated(n_time_steps: int, trend_coeff: List[float], alphas: List[float], sigmas: List[float], time_series_columns: List[str]) -> pd.DataFrame:
    assert len(alphas) == len(sigmas)

    trend_time_series = np.full(n_time_steps, trend_coeff[0], dtype=float)
    for t in range(n_time_steps):
        for i in range(1, len(trend_coeff)):
            trend_time_series[t] += trend_coeff[i] * (t**i)
    n_time_series = len(sigmas)
    df = pd.DataFrame(index=range(n_time_steps))
    for i in range(n_time_series):
        y = np.random.normal(0, sigmas[i], n_time_steps)
        y = np.cumsum(y) + trend_time_series + alphas[i]
        df.loc[:, time_series_columns[i]] = y
    df.loc[:, Columns.trend.value] = trend_time_series
    return df


def simulate_cointegrated(n_time_steps: int, alphas: List[float], betas: List[float], sigmas: List[float], phi: float, time_series_columns: List[str]) -> pd.DataFrame:
    assert len(alphas) == len(sigmas)
    assert len(betas) == len(alphas) - 1
    assert len(alphas) >= 1

    n_time_series = len(alphas)
    y = np.zeros((n_time_series, n_time_steps))
    for i in range(n_time_series - 1):
        y[i, :] = np.random.normal(0, sigmas[i], n_time_steps)
        y[i, :] = np.cumsum(y[i, :]) + alphas[i]
    y[n_time_series - 1, :] = alphas[-1] + np.random.normal(0, sigmas[-1], n_time_steps)
    for i in range(n_time_series - 1):
        y[n_time_series - 1, :] += betas[i] * y[i, :]
    error = sigmas[-1]
    for t in range(n_time_steps):
        if t > 0:
            error *= phi
        y[n_time_series - 1, t] += error

    df = pd.DataFrame(index=range(n_time_steps))
    for i in range(n_time_series):
        df.loc[:, time_series_columns[i]] = y[i, :]
    return df


def get_diff_time_series(df: pd.DataFrame, time_series_columns: List[str]) -> pd.DataFrame:
    assert len(time_series_columns) > 1
    df_diff = pd.DataFrame()
    for i in range(len(time_series_columns)):
        for j in range(i + 1, len(time_series_columns)):
            df_diff.loc[:, f"{Columns.diff.value}({time_series_columns[i]}, {time_series_columns[j]})"] = df[time_series_columns[i]] - df[time_series_columns[j]]
    return df_diff


def main():
    np.random.seed(seed=4)
    data_dir = "../data/simulation"

    # n_time_steps = 1000
    n_time_series = 2
    time_series_columns = [get_time_series_label(time_series_id=i + 1) for i in range(n_time_series)]
    # sigmas = list(np.random.uniform(0.5, 1.0, n_time_series))
    #
    # # Generated a pair of non-cointegrated time series using a quadratic trend
    # alphas = [1 * (1 + i * 0.01) for i in range(n_time_series)]
    # trend_coeff = [100, 0.1, -2e-4]
    # df = simulate_non_cointegrated(n_time_steps=n_time_steps, trend_coeff=trend_coeff, alphas=alphas, sigmas=sigmas, time_series_columns=time_series_columns)
    # plot_file = os.path.join(data_dir, "non_cointegrated.html")
    # plot_time_series(df=df, plot_file=plot_file, title="Simulated Cointegrated")
    # plot_time_series(
    #     df=get_diff_time_series(df=df, time_series_columns=time_series_columns), plot_file=plot_file.replace(".html", "_diff.html"), title="Simulated Cointegrated Differences"
    # )
    #
    # # Generate a pair of cointegrated time series
    # alphas = [100 for _ in range(n_time_series - 1)]
    # alphas.append(0)
    # betas = list(np.random.uniform(0.5, 1, n_time_series - 1))
    # phi = 0.9
    # df = simulate_cointegrated(n_time_steps=n_time_steps, alphas=alphas, betas=betas, sigmas=sigmas, phi=phi, time_series_columns=time_series_columns)
    # plot_file = os.path.join(data_dir, "cointegrated.html")
    # plot_time_series(df=df, plot_file=plot_file, title="Simulated Non-Cointegrated")
    # plot_time_series(
    #     df=get_diff_time_series(df=df, time_series_columns=time_series_columns), plot_file=plot_file.replace(".html", "_diff.html"), title="Simulated Non-Cointegrated Differences"
    # )

    n_time_steps = 1000
    ou_residual_model_specs = OrnsteinUhlenbeckSpecification(
        ornstein_uhlenbeck_half_life_mean=10,
        ornstein_uhlenbeck_half_life_period=0,
        ornstein_uhlenbeck_half_life_max_variation_fraction=0.1,
        white_noise_sigma=0.1,
        ornstein_uhlenbeck_target=0.0,
    )
    garch11_residual_model_specs = GarchSpecification(residual_model_id=ResidualModelId.GARCH11, garch_alphas=np.array([0.3]), garch_betas=np.array([0.6]), white_noise_sigma=0.1)
    simulation = Simulate(
        n_time_steps=n_time_steps,
        x_0=500,
        x_sigma=0.1,
        beta_0_mean=0,
        beta_0_sigma=0,
        beta_1_mean=2,
        beta_1_period=200,
        beta_1_max_variation_fraction=0.005,
        residual_model_specifications=garch11_residual_model_specs,
    )
    # plot_file = os.path.join(data_dir, "cointegrated_OU.html")
    # plot_time_series(df=simulation.df, plot_file=plot_file, title="Simulated Cointegrated With Ornstein-Uhlenbeck")
    # plot_time_series(
    #     df=get_diff_time_series(df=simulation.df, time_series_columns=time_series_columns),
    #     plot_file=plot_file.replace(".html", "_diff.html"),
    #     title="Simulated Non-Cointegrated Differences",
    # )
    simulation.df.to_csv(os.path.join(data_dir, "data_OU.csv"))


if __name__ == "__main__":
    main()
