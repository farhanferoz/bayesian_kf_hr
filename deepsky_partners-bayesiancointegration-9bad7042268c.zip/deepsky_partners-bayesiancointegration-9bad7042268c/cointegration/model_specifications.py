from enum import Enum
from typing import Optional, Tuple, List
import numpy as np

from cointegration.kalman_filter_cointegration import (
    ResidualModel,
    KalmanFilterCointegration,
    Data,
    ObjectiveFunction,
)
from cointegration.constants import Constants
from cointegration.residual_models import get_rate_from_half_life, SimpleCointegration, OrnsteinUhlenbeck, Garch, ResidualModelId
from optimisers.priors import Prior, NormalPrior, ZeroUnionUniformInLogPrior


class ModelType(Enum):
    DYNAMIC_HEDGE_RATIOS_WITH_GARCH00 = (ResidualModelId.GARCH00, False, True)
    DYNAMIC_HEDGE_RATIOS_WITH_GARCH11 = (ResidualModelId.GARCH11, False, True)
    DYNAMIC_HEDGE_RATIOS_WITH_DYNAMIC_COINTEGRATION = (ResidualModelId.SIMPLE_COINTEGRATION, False, False)
    DYNAMIC_HEDGE_RATIOS_WITH_STATIC_COINTEGRATION = (ResidualModelId.SIMPLE_COINTEGRATION, False, True)
    DYNAMIC_HEDGE_RATIOS_WITH_DYNAMIC_OU = (ResidualModelId.ORNSTEIN_UHLENBECK, False, False)
    DYNAMIC_HEDGE_RATIOS_WITH_STATIC_OU = (ResidualModelId.ORNSTEIN_UHLENBECK, False, True)
    STATIC_HEDGE_RATIOS_WITH_GARCH00 = (ResidualModelId.GARCH00, True, True)
    STATIC_HEDGE_RATIOS_WITH_GARCH11 = (ResidualModelId.GARCH11, True, True)
    STATIC_HEDGE_RATIOS_WITH_COINTEGRATION = (ResidualModelId.SIMPLE_COINTEGRATION, True, True)
    STATIC_HEDGE_RATIOS_WITH_OU = (ResidualModelId.ORNSTEIN_UHLENBECK, True, True)

    def __init__(self, residual_model_id: ResidualModelId, are_hedge_ratios_static: bool, is_residual_model_static: bool):
        self.residual_model_id = residual_model_id
        self.are_hedge_ratios_static = are_hedge_ratios_static
        self.is_residual_model_static = is_residual_model_static
        if self.are_hedge_ratios_static:
            assert self.is_residual_model_static

        self.label = f"{'STATIC' if are_hedge_ratios_static else 'DYNAMIC'}_HR_{'STATIC' if is_residual_model_static else 'DYNAMIC'}_{self.residual_model_id.label}"
        self.n_kf_non_beta_state_params = self.residual_model_id.n_state_params
        self.n_non_state_non_sigma_params = self.residual_model_id.n_non_state_non_sigma_params


class ModelSpecifications:
    def __init__(
        self,
        data: Data,
        model_type: ModelType,
        objective_function: ObjectiveFunction,
        kf_betas_initial: Optional[np.array],
        kf_non_beta_state_params_initial: Optional[np.array],
        kf_beta_sigmas_initial: Optional[np.array],
        kf_non_beta_state_param_sigmas_initial: Optional[np.array],
        residual_model_non_state_non_sigma_params: Optional[np.array],
        garch_sigmas_initial: Optional[np.array],
        garch_errors_initial: Optional[np.array],
        guess_initial_state_params_and_sigmas: bool,
        guess_initial_garch_sigmas_and_errors: bool,
    ):
        self.data = data
        self.model_type = model_type
        self.objective_function = objective_function
        self.kf_betas_initial = kf_betas_initial
        self.kf_non_beta_state_params_initial = kf_non_beta_state_params_initial
        self.kf_beta_sigmas_initial = kf_beta_sigmas_initial
        self.kf_non_beta_state_param_sigmas_initial = kf_non_beta_state_param_sigmas_initial
        self.residual_model_non_state_non_sigma_params = residual_model_non_state_non_sigma_params
        self.garch_sigmas_initial = garch_sigmas_initial
        self.garch_errors_initial = garch_errors_initial
        self.guess_initial_state_params_and_sigmas = guess_initial_state_params_and_sigmas
        self.guess_initial_garch_sigmas_and_errors = guess_initial_garch_sigmas_and_errors

        self.garch_order_p = self.model_type.residual_model_id.garch_order_p
        self.garch_order_q = self.model_type.residual_model_id.garch_order_q

        self.ou_mean_reversion_max_half_life_sec = self.data.n_time * self.data.dt_median * 5
        self.n_free_params = 0

        # number of free hedge ratios to be estimated by KF
        self.n_kf_betas = self.data.n_x + 1
        # number free non hedge ratios to be estimated by KF
        self.n_kf_non_beta_state_params = self.model_type.n_kf_non_beta_state_params

        self.beta_transition_sigmas = np.full(self.n_kf_betas, np.nan)
        if self.model_type.are_hedge_ratios_static:
            assert not self.guess_initial_state_params_and_sigmas
            self._set_sigmas_for_static_hedge_ratios()
            self.n_kf_beta_transition_sigmas_free = 0
        else:
            self.n_kf_beta_transition_sigmas_free = self.n_kf_betas

        if self.model_type.is_residual_model_static:
            self._set_sigmas_for_static_residual_model()
            self.n_kf_non_beta_transition_sigmas_free = 0
        else:
            self.n_kf_non_beta_transition_sigmas_free = self.n_kf_non_beta_state_params

        if self.guess_initial_state_params_and_sigmas:
            self._set_initial_state_params_and_sigmas()

        if self.guess_initial_garch_sigmas_and_errors:
            self._set_initial_garch_sigmas_and_errors()

        self.estimate_residual_model_non_state_non_sigma_params = False
        self.n_residual_model_non_state_non_sigma_params_free = 0
        if self.model_type.n_kf_non_beta_state_params == 0:
            assert self.residual_model_non_state_non_sigma_params is None
        else:
            if self.residual_model_non_state_non_sigma_params is None:
                self.estimate_residual_model_non_state_non_sigma_params = True
                self.n_residual_model_non_state_non_sigma_params_free = self.model_type.n_non_state_non_sigma_params

        self.kf_estimate_betas_initial = self.kf_betas_initial is None
        if not self.kf_estimate_betas_initial:
            assert len(self.kf_betas_initial) == self.n_kf_betas
            # if initial beta values are fixed then the initial beta sigma values should also be provided
            assert (self.kf_beta_sigmas_initial is not None) and (len(self.kf_beta_sigmas_initial) == self.n_kf_betas)

        self.kf_estimate_beta_sigmas_initial = self.kf_beta_sigmas_initial is None

        self.kf_estimate_non_beta_state_params_initial = (self.kf_non_beta_state_params_initial is None) and (self.n_kf_non_beta_state_params > 0)
        if not self.kf_estimate_non_beta_state_params_initial:
            if self.n_kf_non_beta_state_params == 0:
                self.kf_non_beta_state_params_initial = np.zeros(0)
            else:
                assert len(self.kf_non_beta_state_params_initial) == self.n_kf_non_beta_state_params
            # if initial non-beta state variable values are fixed then the initial non-beta state variable sigma values should also be provided
            assert (self.kf_non_beta_state_param_sigmas_initial is not None) and (len(self.kf_non_beta_state_param_sigmas_initial) == self.n_kf_non_beta_state_params)

        self.kf_estimate_non_beta_state_params_sigmas_initial = self.kf_non_beta_state_param_sigmas_initial is None

        self.n_kf_betas_initial_free = self.n_kf_betas if self.kf_estimate_betas_initial else 0
        self.n_kf_non_beta_state_params_initial_free = self.n_kf_non_beta_state_params if self.kf_estimate_non_beta_state_params_initial else 0
        self.n_kf_beta_sigmas_initial_free = self.n_kf_betas if self.kf_estimate_beta_sigmas_initial else 0
        self.n_kf_non_beta_state_param_sigmas_initial_free = self.n_kf_non_beta_state_params if self.kf_estimate_non_beta_state_params_sigmas_initial else 0

        # this is the number of initial state parameters to be estimated (outside KF i.e. by the optimiser)
        self.n_kf_initial_state_params_free = self.n_kf_betas_initial_free + self.n_kf_non_beta_state_params_initial_free
        # this is the number of initial state parameter sigmas to be estimated (outside KF i.e. by the optimiser)
        self.n_kf_initial_state_param_sigmas_free = self.n_kf_beta_sigmas_initial_free + self.n_kf_non_beta_state_param_sigmas_initial_free
        # this is the number of state transition sigmas to be estimated (outside KF i.e. by the optimiser)
        self.n_kf_state_transition_sigmas_free = self.n_kf_beta_transition_sigmas_free + self.n_kf_non_beta_transition_sigmas_free
        # this is the total number of free parameters associated with KF that will be estimated by the optimiser
        self.n_kf_optimiser_params_free = (
            self.n_kf_initial_state_params_free
            + self.n_kf_initial_state_param_sigmas_free
            + self.n_kf_state_transition_sigmas_free
            + self.n_residual_model_non_state_non_sigma_params_free
        )

        self.garch_estimate_sigmas_initial = (self.garch_order_p > 0) and (self.garch_sigmas_initial is None)
        if (self.garch_order_p > 0) and (not self.garch_estimate_sigmas_initial):
            assert len(self.garch_sigmas_initial) == self.garch_order_p

        self.garch_estimate_errors_initial = (self.garch_order_q > 0) and (self.garch_errors_initial is None)
        if (self.garch_order_q > 0) and (not self.garch_estimate_errors_initial):
            assert len(self.garch_errors_initial) == self.garch_order_q

        # number of free GARCH parameters which will be estimated outside KF
        self.n_garch_coeff = self.garch_order_p + self.garch_order_q
        self.n_garch_sigmas_initial_free = self.garch_order_p if self.garch_estimate_sigmas_initial else 0
        self.n_garch_errors_initial_free = self.garch_order_q if self.garch_estimate_errors_initial else 0
        self.n_garch_optimiser_params_free = self.n_garch_coeff + self.n_garch_sigmas_initial_free + self.n_garch_errors_initial_free + 1

        self.n_free_params = self.n_kf_optimiser_params_free + self.n_garch_optimiser_params_free

        self.residual_model = self._get_residual_model()
        self.beta_initial_values = np.full(self.n_kf_betas, np.nan) if self.kf_estimate_betas_initial else self.kf_betas_initial
        self.beta_initial_sigmas = np.full(self.n_kf_betas, np.nan) if self.kf_estimate_beta_sigmas_initial else self.kf_beta_sigmas_initial
        self.kf_cointegration = KalmanFilterCointegration(
            data=data,
            residual_model=self.residual_model,
            beta_transition_sigmas=self.beta_transition_sigmas,
            beta_initial_values=self.beta_initial_values,
            beta_initial_sigmas=self.beta_initial_sigmas,
            objective_function=self.objective_function,
        )

        self.param_names = []
        self.param_priors = []
        self.set_model_params(param_values=np.zeros(self.n_free_params), set_param_names=True, set_param_priors=True)

    def _set_sigmas_for_static_hedge_ratios(self) -> None:
        assert self.model_type.are_hedge_ratios_static
        self.kf_beta_sigmas_initial = np.zeros(self.n_kf_betas)
        self.beta_transition_sigmas = np.zeros(self.n_kf_betas)

    def _set_sigmas_for_static_residual_model(self) -> None:
        assert self.model_type.is_residual_model_static
        self.kf_non_beta_state_param_sigmas_initial = np.zeros(self.n_kf_non_beta_state_params)

    def _set_initial_state_params_and_sigmas(self) -> None:
        if self.kf_betas_initial is None:
            self.kf_betas_initial = np.zeros(self.n_kf_betas)
            self.kf_betas_initial[0] = 0.0
            for i in range(self.n_kf_betas - 1):
                self.kf_betas_initial[i + 1] = self.data.y[0] / self.data.x[i, 0]
        if self.kf_beta_sigmas_initial is None:
            self.kf_beta_sigmas_initial = np.zeros(self.n_kf_betas)
            self.kf_beta_sigmas_initial[0] = self.data.y_sigma
            for i in range(self.n_kf_betas - 1):
                self.kf_beta_sigmas_initial[i + 1] = self.data.y_div_x_sigma[i]
        if self.kf_non_beta_state_params_initial is None:
            self.kf_non_beta_state_params_initial = np.zeros(self.n_kf_non_beta_state_params)
            if self.model_type.residual_model_id == ResidualModelId.SIMPLE_COINTEGRATION:
                # phi
                self.kf_non_beta_state_params_initial[0] = 0.0
            elif self.model_type.residual_model_id == ResidualModelId.ORNSTEIN_UHLENBECK:
                # lambda (mean reversion rate)
                self.kf_non_beta_state_params_initial[0] = get_rate_from_half_life(half_life=self.data.dt_median)
            elif self.model_type.residual_model_id not in [ResidualModelId.GARCH00, ResidualModelId.GARCH11]:
                raise ValueError(f"Residual model {self.model_type.residual_model_id.label} not supported.")
        if self.kf_non_beta_state_param_sigmas_initial is None:
            self.kf_non_beta_state_param_sigmas_initial = np.zeros(self.n_kf_non_beta_state_params)
            if self.model_type.residual_model_id == ResidualModelId.SIMPLE_COINTEGRATION:
                # phi
                self.kf_non_beta_state_param_sigmas_initial[0] = 0.5
            elif self.model_type.residual_model_id == ResidualModelId.ORNSTEIN_UHLENBECK:
                # lambda (mean reversion rate)
                self.kf_non_beta_state_param_sigmas_initial[0] = get_rate_from_half_life(half_life=self.data.dt_median) / 3
            elif self.model_type.residual_model_id not in [ResidualModelId.GARCH00, ResidualModelId.GARCH11]:
                raise ValueError(f"Residual model {self.model_type.residual_model_id.label} not supported.")

    def _set_initial_garch_sigmas_and_errors(self) -> None:
        if self.garch_sigmas_initial is None:
            self.garch_sigmas_initial = np.zeros(self.garch_order_p)
        if self.garch_errors_initial is None:
            self.garch_errors_initial = np.zeros(self.garch_order_q)

    def _get_residual_model(self) -> ResidualModel:
        white_noise_sigma = 0.0
        if self.model_type.residual_model_id == ResidualModelId.SIMPLE_COINTEGRATION:
            phi_initial = np.nan if self.kf_estimate_non_beta_state_params_initial else self.kf_non_beta_state_params_initial[0]
            if self.model_type.is_residual_model_static:
                phi_sigma_initial = 0.0
                phi_transition_sigma = 0.0
            else:
                phi_sigma_initial = np.nan if self.kf_estimate_non_beta_state_params_sigmas_initial else self.kf_non_beta_state_param_sigmas_initial[0]
                phi_transition_sigma = np.nan
            residual_model = SimpleCointegration(
                white_noise_sigma=white_noise_sigma, phi_transition_sigma=phi_transition_sigma, phi_initial_sigma=phi_sigma_initial, phi_initial=phi_initial
            )
        elif self.model_type.residual_model_id == ResidualModelId.ORNSTEIN_UHLENBECK:
            mean_reversion_target = np.nan if self.estimate_residual_model_non_state_non_sigma_params else self.residual_model_non_state_non_sigma_params[0]
            mean_reversion_rate_initial = np.nan if self.kf_estimate_non_beta_state_params_initial else self.kf_non_beta_state_params_initial[0]
            if self.model_type.is_residual_model_static:
                mean_reversion_rate_initial_sigma = 0.0
                mean_reversion_rate_transition_sigma = 0.0
            else:
                mean_reversion_rate_initial_sigma = np.nan if self.kf_estimate_non_beta_state_params_sigmas_initial else self.kf_non_beta_state_param_sigmas_initial[0]
                mean_reversion_rate_transition_sigma = np.nan
            residual_model = OrnsteinUhlenbeck(
                white_noise_sigma=white_noise_sigma,
                mean_reversion_rate_transition_sigma=mean_reversion_rate_transition_sigma,
                mean_reversion_rate_initial_sigma=mean_reversion_rate_initial_sigma,
                mean_reversion_rate_initial=mean_reversion_rate_initial,
                mean_reversion_target=mean_reversion_target,
            )
        elif self.model_type.residual_model_id in [ResidualModelId.GARCH00, ResidualModelId.GARCH11]:
            residual_model = Garch(
                residual_model_id=self.model_type.residual_model_id,
                white_noise_sigma=white_noise_sigma,
                alpha=np.zeros(self.garch_order_q),
                beta=np.zeros(self.garch_order_p),
                estimate_sigmas_initial=self.garch_estimate_sigmas_initial,
                estimate_errors_initial=self.garch_estimate_errors_initial,
                sigmas_initial=np.zeros(self.garch_order_p) if self.garch_estimate_sigmas_initial else self.garch_sigmas_initial,
                errors_initial=np.zeros(self.garch_order_q) if self.garch_estimate_errors_initial else self.garch_errors_initial,
            )
        else:
            raise ValueError(f"Residual model {self.model_type.residual_model_id} not recognised.")
        return residual_model

    @staticmethod
    def _get_values(values: np.array, start_idx: int, n_values: int) -> Tuple[int, np.array]:
        return start_idx + n_values, values[start_idx : start_idx + n_values]

    def _set_beta_sigma_priors(self) -> List[Prior]:
        beta_sigma_priors = []
        # prior on beta_0 sigma
        zero_prior_probability = Constants.zero_prior_probability_for_sigmas.value
        max_value = self.data.y_sigma * 5
        non_zero_min_value = min(self.data.y_sigma / 100, self.data.y_tick_size / (5 * np.sqrt(self.data.dt_median)))
        beta_sigma_priors.append(ZeroUnionUniformInLogPrior(zero_prior_probability=zero_prior_probability, non_zero_min_value=non_zero_min_value, max_value=max_value))
        # priors on hedge ratio beta sigmas
        for i in range(self.n_kf_betas - 1):
            max_value = self.data.y_div_x_sigma[i] * 5
            non_zero_min_value = min(self.data.y_div_x_sigma[i] / 100, self.data.y_tick_size / (5 * self.data.x[i, 0]))
            beta_sigma_priors.append(ZeroUnionUniformInLogPrior(zero_prior_probability=zero_prior_probability, non_zero_min_value=non_zero_min_value, max_value=max_value))
        return beta_sigma_priors

    def _set_beta_priors(self) -> List[Prior]:
        beta_priors = []
        # prior on beta_0
        beta_priors.append(NormalPrior(mu=0, sigma=self.data.y_sigma * 5))
        # priors on hedge ratio betas
        for i in range(self.n_kf_betas - 1):
            beta_priors.append(NormalPrior(mu=self.data.y[0] / self.data.x[i, 0], sigma=self.data.y_div_x_sigma[i] * 5))
        return beta_priors

    def set_model_params(self, param_values: np.array, set_param_names: bool = False, set_param_priors: bool = False) -> None:
        assert len(param_values) == self.n_free_params
        if set_param_names:
            self.param_names.clear()
        if set_param_priors:
            self.param_priors.clear()
        k = 0
        # set the beta transition sigmas
        if self.n_kf_beta_transition_sigmas_free > 0:
            k, self.beta_transition_sigmas = self._get_values(values=param_values, start_idx=k, n_values=self.n_kf_betas)
            if set_param_names:
                self.param_names += [f"beta_{i}_transition_sigma" for i in range(self.n_kf_betas)]
            if set_param_priors:
                beta_transition_sigma_priors = self._set_beta_sigma_priors()
                self.param_priors += beta_transition_sigma_priors
        # if initial beta values need to be estimated then set these
        if self.kf_estimate_betas_initial:
            k, self.beta_initial_values = self._get_values(values=param_values, start_idx=k, n_values=self.n_kf_betas)
            if set_param_names:
                self.param_names += [f"beta_{i}_initial" for i in range(self.n_kf_betas)]
            if set_param_priors:
                beta_initial_priors = self._set_beta_priors()
                self.param_priors += beta_initial_priors
        # if initial beta sigma values need to be estimated then set these
        if self.kf_estimate_beta_sigmas_initial:
            k, self.beta_initial_sigmas = self._get_values(values=param_values, start_idx=k, n_values=self.n_kf_betas)
            if set_param_names:
                self.param_names += [f"beta_{i}_sigma_initial" for i in range(self.n_kf_betas)]
            if set_param_priors:
                beta_sigma_initial_priors = self._set_beta_sigma_priors()
                self.param_priors += beta_sigma_initial_priors
        # set the residual model parameters
        additional_info = []
        if self.residual_model.residual_model_id == ResidualModelId.ORNSTEIN_UHLENBECK:
            additional_info += [self.data.y_sigma, self.ou_mean_reversion_max_half_life_sec]
        k, residual_model_param_names, residual_model_param_priors = self.residual_model.extract_and_set_model_params(
            param_values=param_values,
            start_idx=k,
            estimate_residual_model_non_state_non_sigma_params=self.estimate_residual_model_non_state_non_sigma_params,
            kf_estimate_non_beta_state_params_initial=self.kf_estimate_non_beta_state_params_initial,
            kf_estimate_non_beta_state_params_sigmas_initial=self.kf_estimate_non_beta_state_params_sigmas_initial,
            is_model_static=self.model_type.is_residual_model_static,
            set_param_names=set_param_names,
            set_param_priors=set_param_priors,
            y_tick_size=self.data.y_tick_size,
            y_sigma=self.data.y_sigma,
            additional_info=additional_info,
        )
        if set_param_names:
            self.param_names += residual_model_param_names
        if set_param_priors:
            self.param_priors += residual_model_param_priors
        # reset parameters for kalman filter cointegration
        self.kf_cointegration.reset_parameters(
            residual_model=self.residual_model,
            beta_transition_sigmas=self.beta_transition_sigmas,
            beta_initial_values=self.beta_initial_values,
            beta_initial_sigmas=self.beta_initial_sigmas,
        )
