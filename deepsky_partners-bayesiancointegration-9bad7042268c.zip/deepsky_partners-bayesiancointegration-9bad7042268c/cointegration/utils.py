import numpy as np
from cointegration.constants import Constants


def fix_numeric_for_infinity(values: np.ndarray) -> np.ndarray:
    """
    if any float in the input array is within 1 unit of infinity then set it to infinity
    :param values: input array
    :return: array with fixed values
    """
    fixed_values = np.copy(values)
    fixed_values = np.where(np.abs(np.abs(fixed_values) - Constants.infinity.value) <= 1, np.sign(fixed_values) * Constants.infinity.value, fixed_values)
    return fixed_values
