import numpy as np
from typing import Optional, Tuple, Dict

import pandas as pd
from filterpy.kalman import KalmanFilter as filterPyKF
from enum import Enum

from cointegration.data import Data
from cointegration.residual_models import ResidualModel, ResidualModelId


class ObjectiveFunction(Enum):
    LOG_LIKE = ("log_like", False, False, True)
    UNWEIGHTED_PNL = ("unweighted_pnl", True, False, False)
    WEIGHTED_PNL = ("weighted_pnl", True, False, True)
    UNWEIGHTED_RETURN = ("unweighted_return", True, False, False)
    WEIGHTED_RETURN = ("weighted_return", True, False, True)
    UNWEIGHTED_SHARPE = ("unweighted_sharpe", True, True, False)
    WEIGHTED_SHARPE = ("weighted_sharpe", True, True, True)

    def __init__(self, label: str, is_pnl_based: bool, is_sharpe: bool, is_weighted: bool):
        self.label = label
        self.is_pnl_based = is_pnl_based
        self.is_sharpe = is_sharpe
        self.is_weighted = is_weighted


class BestParameterSelectionCriterion(Enum):
    BEST_FIT = "bfit"
    BEST_SHARPE_AMONG_BEST_FIT = "bsharpe_from_bfit"


class TradeComponent(Enum):
    Y = "Y"
    X = "X"
    COMBINED = "COMBINED"


class Columns(Enum):
    objective_function_value = "objective_function_value"
    unweighted_capital = "unweighted_capital"
    weighted_capital = "weighted_capital"
    y = "y"
    x = "x"
    combined = "combined"
    y_pred_mean = "y_pred_mean"
    y_pred_sigma = "y_pred_sigma"
    y_residual = "y_residual"
    error = "error"


class KalmanFilterCointegration:
    def __init__(
        self,
        data: Data,
        residual_model: ResidualModel,
        beta_transition_sigmas: np.array,
        beta_initial_values: Optional[np.array] = None,
        beta_initial_sigmas: Optional[np.array] = None,
        objective_function: ObjectiveFunction = ObjectiveFunction.LOG_LIKE,
    ):
        self.objective_function = objective_function
        self.data = data
        self.n_betas = 1 + self.data.n_x
        self.n_residual_model_thetas = 0
        self.n_dim_theta = 0
        # all predictions before i_start are ignored in likelihood & P&L calculations
        self.i_start = 1

        self.residual_model: Optional[ResidualModel] = None
        self.beta_transition_sigmas: Optional[np.array] = None
        self.beta_initial_values: Optional[np.array] = None
        self.beta_initial_sigmas: Optional[np.array] = None
        self.checking_for_cointegration = False

        # transition matrix is an identity matrix
        self.transition_matrix: Optional[np.ndarray] = None
        self.state_transition_sigma: Optional[np.ndarray] = None
        self.transition_covariance: Optional[np.ndarray] = None
        self.initial_state_mean: Optional[np.ndarray] = None
        self.initial_state_sigma: Optional[np.ndarray] = None
        self.initial_state_covariance: Optional[np.ndarray] = None
        self.is_model_static = False
        self.do_kf_per_step = False
        self.state_means: Optional[np.ndarray] = None
        self.state_covs: Optional[np.ndarray] = None
        self.y_mean_pred: Optional[np.ndarray] = None
        self.y_sigma_pred: Optional[np.ndarray] = None
        self.y_residuals: Optional[np.ndarray] = None
        self.errors: Optional[np.ndarray] = None
        self.y_sigma_obs: Optional[np.ndarray] = None
        self.y_sigma: Optional[np.ndarray] = None
        self.objective_function_value = np.nan
        self.pnl_based_statistics = self._initialise_pnl_based_statistics()
        self.state_param_names = []
        self.state_param_sigma_names = []

        self.reset_parameters(
            residual_model=residual_model,
            beta_transition_sigmas=beta_transition_sigmas,
            beta_initial_values=beta_initial_values,
            beta_initial_sigmas=beta_initial_sigmas,
        )

    @staticmethod
    def _get_pnl_statistic_col(trade_component: TradeComponent, statistic: str) -> str:
        if statistic == ObjectiveFunction.LOG_LIKE.label:
            assert trade_component == TradeComponent.COMBINED
            col = statistic
        else:
            col = f"{trade_component.value}_{statistic}"
        return col

    def _initialise_pnl_based_statistics(self) -> Dict[str, float]:
        pnl_based_statistics = {ObjectiveFunction.LOG_LIKE.label: np.nan}
        for trade_component in TradeComponent:
            for statistic in [
                ObjectiveFunction.WEIGHTED_PNL.label,
                ObjectiveFunction.UNWEIGHTED_PNL.label,
                ObjectiveFunction.WEIGHTED_RETURN.label,
                ObjectiveFunction.UNWEIGHTED_RETURN.label,
                ObjectiveFunction.WEIGHTED_SHARPE.label,
                ObjectiveFunction.UNWEIGHTED_SHARPE.label,
                Columns.weighted_capital.value,
                Columns.unweighted_capital.value,
            ]:
                pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=statistic)] = 0.0
        return pnl_based_statistics

    def reset_parameters(
        self,
        residual_model: ResidualModel,
        beta_transition_sigmas: np.array,
        beta_initial_values: Optional[np.array] = None,
        beta_initial_sigmas: Optional[np.array] = None,
    ) -> None:
        self.n_residual_model_thetas = len(residual_model.get_sigmas(for_initial=True))
        self.n_dim_theta = self.n_betas + self.n_residual_model_thetas

        self.residual_model = residual_model
        self.beta_transition_sigmas = beta_transition_sigmas.astype(np.double)
        self.beta_initial_values = (beta_initial_values if beta_initial_values is not None else self.calculate_initial_beta_estimate()).astype(np.double)
        self.beta_initial_sigmas = (beta_initial_sigmas if beta_initial_sigmas is not None else self.calculate_initial_beta_sigmas()).astype(np.double)

        self.checking_for_cointegration = self.residual_model.is_active()

        assert len(beta_transition_sigmas) == self.n_dim_theta - self.n_residual_model_thetas
        if beta_initial_values is not None:
            assert len(beta_initial_values) == self.n_dim_theta - self.n_residual_model_thetas

        # transition matrix is an identity matrix
        self.transition_matrix = np.eye(self.n_dim_theta).astype(np.double)
        self.state_transition_sigma = self._create_theta(additional_parameters=self.residual_model.get_sigmas(for_initial=False), beta=self.beta_transition_sigmas)
        # self.state_transition_sigma = self.beta_transition_sigmas
        self.transition_covariance = np.square(self.state_transition_sigma) * np.eye(self.n_dim_theta)
        self.initial_state_mean = self._create_theta(additional_parameters=self.residual_model.get_initial_parameter_values(), beta=self.beta_initial_values)
        # self.initial_state_mean = self.beta_initial_values
        # set the covariance matrix of initial estimate of state parameters to a diagonal matrix with covariances being half of the square of initial estimates
        self.initial_state_sigma = np.concatenate((self.residual_model.get_sigmas(for_initial=True), self.beta_initial_sigmas))
        # self.initial_state_sigma = self.beta_initial_sigmas
        self.initial_state_covariance = np.square(self.initial_state_sigma) * np.eye(self.n_dim_theta)
        self.do_kf_per_step = self.checking_for_cointegration or ((self.residual_model == ResidualModelId.ORNSTEIN_UHLENBECK) and np.isnan(self.data.dt))
        self.is_model_static = np.all(self.initial_state_sigma == 0) and np.all(self.state_transition_sigma == 0)

        self.state_means = np.full((self.data.n_time, self.n_dim_theta), np.nan)
        self.state_covs = np.full((self.data.n_time, self.n_dim_theta, self.n_dim_theta), np.nan)
        self.y_mean_pred = np.full(self.data.n_time, np.nan)
        self.y_sigma_pred = np.full(self.data.n_time, np.nan)
        self.y_residuals = np.full(self.data.n_time, np.nan)
        self.errors = np.full(self.data.n_time, np.nan)
        self.y_sigma_obs = np.full(self.data.n_time, np.nan)
        self.y_sigma = np.full(self.data.n_time, np.nan)
        self.objective_function_value = np.nan
        self.pnl_based_statistics = self._initialise_pnl_based_statistics()
        self.state_param_names = self.residual_model.get_state_param_names() + [f"beta{i}" for i in range(self.n_betas)]
        self.state_param_sigma_names = [f"{param_name}_sigma" for param_name in self.state_param_names]

    @staticmethod
    def _create_theta(beta: np.array, additional_parameters: np.array) -> np.array:
        return np.insert(beta, 0, additional_parameters, axis=0)

    def calculate_initial_beta_estimate(self) -> np.array:
        """
        Calculate the initial estimates for beta state parameters
        """
        beta = np.zeros(self.n_dim_theta - self.n_residual_model_thetas)
        beta[0] = 0
        beta[1:] = np.divide(np.full(len(beta) - 1, self.data.y[0]), self.data.x[:, 0])
        return beta

    def calculate_initial_beta_sigmas(self) -> np.array:
        initial_beta_transition_sigmas = np.full(self.n_betas, np.square(np.max(self.calculate_initial_beta_estimate())) / 2)
        initial_beta_transition_sigmas = np.where(self.beta_transition_sigmas == 0, 0, initial_beta_transition_sigmas)
        return initial_beta_transition_sigmas

    def calculate_initial_theta_estimate(self) -> np.array:
        """
        Calculate the initial estimates for state parameters
        """
        beta = self.beta_initial_values
        # return self._create_theta(additional_parameters=self.residual_model_parameters.get_initial_parameter_values(), beta=beta)
        return beta

    def setup_kf(
        self,
        initial_state_mean: Optional[np.array] = None,
        initial_state_covariance: Optional[np.ndarray] = None,
    ) -> filterPyKF:
        kf = filterPyKF(dim_x=self.n_dim_theta, dim_z=self.data.n_x)
        kf.F = self.transition_matrix
        kf.Q = self.transition_covariance
        if initial_state_mean is not None:
            assert initial_state_covariance is not None
            kf.x = initial_state_mean
            kf.P = initial_state_covariance
        return kf

    @staticmethod
    def predict_kf(kf: filterPyKF) -> Tuple[np.ndarray, np.ndarray]:
        kf.predict()
        state_means_predict = kf.x.copy()
        state_covs_predict = kf.P.copy()
        return state_means_predict, state_covs_predict

    @staticmethod
    def update_kf(kf: filterPyKF, observations: np.array, observation_matrices: np.ndarray, observation_covariance: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        doing_one_step_update = observations.size == 1
        assert doing_one_step_update
        assert observation_matrices is not None
        assert observation_covariance is not None
        # kf.x = filtered_state_mean
        # kf.P = filtered_state_covariance
        kf.H = observation_matrices
        kf.R = observation_covariance
        kf.update(observations)
        state_means_update = kf.x.copy()
        state_covs_update = kf.P.copy()
        return state_means_update, state_covs_update

    def apply(self, calculate_loglike: bool = True, calculate_pnl: bool = True) -> None:
        if self.is_model_static:
            self.state_means[:] = self.initial_state_mean
            self.state_covs[:] = np.zeros((self.n_dim_theta, self.n_dim_theta))
        observation_matrix_hedge_ratios = np.ones((1, self.n_betas))
        if self.do_kf_per_step:
            kf = self.setup_kf() if self.is_model_static else self.setup_kf(initial_state_mean=self.initial_state_mean, initial_state_covariance=self.initial_state_covariance)
            n_start = 1 if np.isnan(self.data.dt) else 0
            for i in range(n_start, self.data.n_time):
                if not self.is_model_static:
                    self.state_means[i], self.state_covs[i] = self.predict_kf(kf)

                last_error = self.residual_model.initial_error if i == 0 else self.errors[i - 1]
                dt = 1.0
                if self.residual_model.residual_model_id == ResidualModelId.ORNSTEIN_UHLENBECK:
                    dt = self.data.times[i] - self.data.times[i - 1] if np.isnan(self.data.dt) else self.data.dt
                observation_noise_sigma = self.residual_model.get_noise_sigma(
                    last_noise_sigma=None if i == 0 else self.y_sigma_obs[i - 1], last_error=None if i == 0 else last_error, dt=dt
                )

                observation_matrix_hedge_ratios[0, 1:] = self.data.x[:, i]
                if self.n_residual_model_thetas > 0:
                    observation_matrix_residual_model = self.residual_model.get_observation_matrix(last_error=last_error, dt=dt)
                    observation_matrix = np.append(observation_matrix_residual_model, observation_matrix_hedge_ratios, axis=1)
                else:
                    observation_matrix = observation_matrix_hedge_ratios

                self.y_mean_pred[i] = np.dot(self.state_means[i], observation_matrix[0])
                self.y_sigma_pred[i] = 0 if self.is_model_static else np.sqrt(np.dot(observation_matrix[0], np.dot(self.state_covs[i], observation_matrix[0].T)))
                self.y_sigma_obs[i] = observation_noise_sigma
                # self.errors[i] = self.data.y[i] - self.y_mean_pred[i]
                self.y_residuals[i] = self.data.y[i] - self.y_mean_pred[i]
                self.errors[i] = (
                    self.y_residuals[i] if self.n_residual_model_thetas == 0 else self.data.y[i] - np.dot(self.state_means[i, -self.n_betas :], observation_matrix_hedge_ratios[0])
                )
                # error_mean = self.residual_model.get_error_mean(last_error=last_error, dt=dt)
                # self.y_residuals[i] = self.errors[i] - error_mean

                if not self.is_model_static:
                    self.update_kf(
                        kf=kf, observations=np.array(self.data.y[i]), observation_matrices=observation_matrix, observation_covariance=np.array([[observation_noise_sigma**2]])
                    )
        else:
            dt = self.data.dt if self.residual_model == ResidualModelId.ORNSTEIN_UHLENBECK else 1.0
            observation_noise_sigma = self.residual_model.get_noise_sigma(last_noise_sigma=None, last_error=None, dt=dt)
            observation_matrices = np.vstack([np.ones(self.data.n_time), self.data.x]).T[:, np.newaxis]
            if not self.is_model_static:
                kf = self.setup_kf(initial_state_mean=self.initial_state_mean, initial_state_covariance=self.initial_state_covariance)
                state_means_update, state_covs_update, state_means_predict, state_covs_predict = kf.batch_filter(
                    zs=self.data.y, Hs=observation_matrices, Rs=np.full((self.data.n_time, 1, 1), observation_noise_sigma**2)
                )
                self.state_means = state_means_predict
                self.state_covs = state_covs_predict

            self.y_mean_pred = np.sum(self.state_means[:] * observation_matrices[:, 0], axis=1)
            if self.is_model_static:
                self.y_sigma_pred[:] = 0
            else:
                for i in range(self.data.n_time):
                    self.y_sigma_pred[i] = np.sqrt(np.dot(observation_matrices[i, 0], np.dot(self.state_covs[i], observation_matrices[i, 0].T)))
            self.y_sigma_obs[:] = observation_noise_sigma
            self.y_residuals[: self.data.n_time] = self.data.y[: self.data.n_time] - self.y_mean_pred[: self.data.n_time]
            self.errors = self.y_residuals
        self.y_sigma = np.sqrt(np.square(self.y_sigma_obs) + np.square(self.y_sigma_pred))
        if (self.objective_function == ObjectiveFunction.LOG_LIKE) or calculate_loglike:
            self._calculate_loglikelihood()
        if self.objective_function.is_pnl_based or calculate_pnl:
            self._calculate_pnl()
        self.objective_function_value = self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=TradeComponent.COMBINED, statistic=self.objective_function.label)]
        if self.objective_function_value <= -1e6:
            print(self.objective_function_value)
            input("")

    def get_prediction_data(self) -> pd.DataFrame:
        data = {}
        data[Columns.y.value] = self.data.y
        for i in range(self.data.n_x):
            data[f"{Columns.x.value}{i}"] = self.data.x[i]
        data[Columns.y_pred_mean.value] = self.y_mean_pred
        data[Columns.y_pred_sigma.value] = self.y_sigma
        data[Columns.y_residual.value] = self.y_residuals
        data[Columns.error.value] = self.errors
        for i in range(len(self.state_param_names)):
            data[self.state_param_names[i]] = self.state_means[:, i]
            data[self.state_param_sigma_names[i]] = np.sqrt(self.state_covs[:, i, i])
        df = pd.DataFrame(data=data)
        return df

    @staticmethod
    def _get_total_return_and_sharpe(pnl_per_trade: np.array, capital_per_trade: np.array, weights_per_trade: np.array) -> Tuple[float, float, float]:
        capital = np.max(weights_per_trade * capital_per_trade)
        returns = pnl_per_trade * weights_per_trade / capital
        total_return = np.sum(returns)
        sharpe = 0.0 if np.all(returns == 0.0) else np.mean(returns) / np.std(returns)
        return total_return, sharpe, capital

    def _calculate_pnl(self) -> None:
        y_positions = np.where(self.errors[self.i_start :] > 0, -1.0, 1.0)
        weights_per_trade = np.abs(self.errors[self.i_start :] / self.y_sigma[self.i_start :]) / np.max(np.abs(self.errors[self.i_start :] / self.y_sigma[self.i_start :]))
        y = self.data.non_scaled_non_shifted_y[self.i_start :]
        x = self.data.non_scaled_non_shifted_x[:, self.i_start :]
        x_point_adj_factor = self.data.y_point_value / self.data.x_point_value
        x_hedge_ratio = self.state_means[self.i_start : -1, -(self.n_betas - 1) :] * x_point_adj_factor * self.data.x_scale
        pnl_per_trade = {TradeComponent.Y: np.diff(y) * y_positions[:-1], TradeComponent.X: -y_positions[:-1] * np.sum(x_hedge_ratio * np.diff(x).T, axis=1)}
        capital_per_trade = {TradeComponent.Y: np.abs(y_positions[:-1]) * y[:-1], TradeComponent.X: np.sum(x[:, :-1].T * np.abs(x_hedge_ratio), axis=1)}
        pnl_per_trade[TradeComponent.COMBINED] = pnl_per_trade[TradeComponent.Y] + pnl_per_trade[TradeComponent.X]
        capital_per_trade[TradeComponent.COMBINED] = capital_per_trade[TradeComponent.Y] + capital_per_trade[TradeComponent.X]
        for trade_component in TradeComponent:
            unweighted_return, unweighted_sharpe, unweighted_capital = self._get_total_return_and_sharpe(
                pnl_per_trade=pnl_per_trade[trade_component], capital_per_trade=capital_per_trade[trade_component], weights_per_trade=np.ones(len(pnl_per_trade[trade_component]))
            )
            weighted_return, weighted_sharpe, weighted_capital = self._get_total_return_and_sharpe(
                pnl_per_trade=pnl_per_trade[trade_component], capital_per_trade=capital_per_trade[trade_component], weights_per_trade=weights_per_trade[:-1]
            )
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=ObjectiveFunction.WEIGHTED_PNL.label)] = np.sum(
                pnl_per_trade[trade_component] * weights_per_trade[:-1]
            )
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=ObjectiveFunction.UNWEIGHTED_PNL.label)] = np.sum(
                pnl_per_trade[trade_component]
            )
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=ObjectiveFunction.WEIGHTED_RETURN.label)] = weighted_return
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=ObjectiveFunction.UNWEIGHTED_RETURN.label)] = unweighted_return
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=ObjectiveFunction.WEIGHTED_SHARPE.label)] = weighted_sharpe
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=ObjectiveFunction.UNWEIGHTED_SHARPE.label)] = unweighted_sharpe
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=Columns.weighted_capital.value)] = weighted_capital
            self.pnl_based_statistics[self._get_pnl_statistic_col(trade_component=trade_component, statistic=Columns.unweighted_capital.value)] = unweighted_capital
        # df = pd.DataFrame(data={"y": y[:-1], "x": x[0, :-1], "pos": y_positions[:-1], "hr": x_hedge_ratio[:, 0], "w": weights_per_trade[:-1], "e": self.errors[self.i_start:-1], "y_pred_mean": self.y_mean_pred[self.i_start:-1], "y_pred_sigma": self.y_sigma_pred[self.i_start:-1], "pnl_y": pnl_per_trade_y, "pnl_x": pnl_per_trade_x})
        # df.to_csv("data.csv")
        # print("D")
        # input('')

    def _calculate_loglikelihood(self) -> None:
        """
        calculate log-likelihood
        """
        loglike = self.pnl_based_statistics[ObjectiveFunction.LOG_LIKE.label]
        if np.isnan(loglike):
            i_end = self.data.n_time
            n = i_end - self.i_start
            loglike = (
                -n * (np.log(2 * np.pi)) / 2
                - np.sum(np.log(self.y_sigma[self.i_start : i_end]))
                - np.sum(np.square(np.divide(self.y_residuals[self.i_start : i_end], self.y_sigma[self.i_start : i_end]))) / 2
            )
        self.pnl_based_statistics[ObjectiveFunction.LOG_LIKE.label] = loglike

    def get_col_for_best_parameter_selection_criterion(
        self, best_parameter_selection_criterion: BestParameterSelectionCriterion, trade_component: TradeComponent = TradeComponent.COMBINED
    ) -> str:
        if (best_parameter_selection_criterion == BestParameterSelectionCriterion.BEST_FIT) or self.objective_function.is_sharpe:
            objective_function = self.objective_function
        elif best_parameter_selection_criterion == BestParameterSelectionCriterion.BEST_SHARPE_AMONG_BEST_FIT:
            objective_function = ObjectiveFunction.WEIGHTED_SHARPE if self.objective_function.is_weighted else ObjectiveFunction.UNWEIGHTED_SHARPE.value
        else:
            raise RuntimeError(f"best_parameter_selection_criterion: {best_parameter_selection_criterion.name} not supported.")
        return self._get_pnl_statistic_col(trade_component=trade_component, statistic=objective_function.label)

    def get_utility_value(self, best_parameter_selection_criterion: BestParameterSelectionCriterion) -> float:
        return self.pnl_based_statistics[self.get_col_for_best_parameter_selection_criterion(best_parameter_selection_criterion=best_parameter_selection_criterion)]
