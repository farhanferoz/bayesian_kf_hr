import numpy as np
from typing import Optional, List, Tuple

from cointegration.constants import Constants
from cointegration.residual_models import get_params_values
from optimisers.priors import UniformPrior, ZeroUnionUniformInLogPrior, UniformInLogPrior, Prior


class Garch:
    def __init__(
        self,
        order_p: int = 0,
        order_q: int = 0,
        w: float = 0,
        beta: np.array = np.zeros(0),
        alpha: np.array = np.zeros(0),
        sigma_initial: Optional[np.array] = None,
        error_initial: Optional[np.array] = None,
    ):
        # order for the moving average part
        self.order_p = 0
        # order for the autoregressive part
        self.order_q = 0
        # intercept term (variance)
        self.w = 0.0
        # moving average coefficients, should be of size order_p
        self.beta: Optional[np.array] = None
        # autoregressive coefficients, should be of size order_q
        self.alpha: Optional[np.array] = None
        # first p sigmas for the moving average part, should be of size order_p
        self.sigma_initial: Optional[np.array] = None
        # first q errors for the autoregressive part, should be of size order_p
        self.error_initial: Optional[np.array] = None

        # current p sigmas for the moving average part, should be of size order_p
        self.errors: Optional[np.array] = None
        # current q errors for the autoregressive part, should be of size order_p
        self.sigmas: Optional[np.array] = None
        self.is_active = False

        self._change_params(order_p=order_p, order_q=order_q, w=w, beta=beta, alpha=alpha, sigma_initial=sigma_initial, error_initial=error_initial)

    def _change_params(self, order_p: int, order_q: int, w: float, beta: np.array, alpha: np.array, sigma_initial: Optional[np.array], error_initial: Optional[np.array]) -> None:
        self.order_p = order_p
        assert self.order_p >= 0
        self.order_q = order_q
        assert self.order_q >= 0
        self.w = w
        assert self.w >= 0
        self.beta = np.copy(beta)
        assert len(self.beta) == self.order_p
        self.alpha = np.copy(alpha)
        assert len(self.alpha) == self.order_q
        self.sigma_initial = sigma_initial if sigma_initial is None else np.copy(sigma_initial)
        self.error_initial = error_initial if error_initial is None else np.copy(error_initial)
        if self.sigma_initial is None:
            self.sigma_initial = np.zeros(self.order_p)
        if self.error_initial is None:
            self.error_initial = np.zeros(self.order_q)
        self.errors = np.copy(self.error_initial)
        self.sigmas = np.copy(self.sigma_initial)
        assert len(self.sigma_initial) == self.order_p
        assert len(self.error_initial) == self.order_q
        assert np.all(self.sigma_initial >= 0)
        self.is_active = (self.order_p > 0) or (self.order_q > 0)

    @staticmethod
    def _create_arr(order: int, current_vals: np.array, initial_vals: np.array) -> np.array:
        if len(current_vals) >= order:
            arr = current_vals[len(current_vals) - order :]
        else:
            arr = np.zeros(order)
            n = order - len(current_vals)
            arr[:n] = initial_vals[order - n]
            arr[n:] = current_vals
        return arr

    def _calculate_variance(self, dt: float) -> float:
        variance = self.w * dt
        if self.order_p > 0:
            variance += np.dot(self.beta, np.square(self.sigmas))
        if self.order_q > 0:
            variance += np.dot(self.alpha, np.square(self.errors))
        return variance

    def apply(self, sigmas: np.array, errors: np.array, dt: float) -> float:
        """
        Calculate the variance using GARCH model
        """
        # assert len(sigmas) == len(errors)
        # if len(sigmas) > 0:
        #     assert np.all(sigmas >= 0)
        if self.order_p > 0:
            self.sigmas = self._create_arr(order=self.order_p, current_vals=sigmas, initial_vals=self.sigma_initial)
        if self.order_q > 0:
            self.errors = self._create_arr(order=self.order_q, current_vals=errors, initial_vals=self.error_initial)
        return self._calculate_variance(dt=dt)

    def apply_incremental(self, sigma: Optional[float], error: Optional[float], dt: float) -> float:
        if (self.order_p > 0) and (sigma is not None):
            if self.order_p > 1:
                self.sigmas[:-1] = self.sigmas[1:]
            self.sigmas[-1] = sigma
        if (self.order_q > 0) and (error is not None):
            if self.order_q > 1:
                self.errors[:-1] = self.errors[1:]
            self.errors[-1] = error
        return self._calculate_variance(dt=dt)

    def extract_and_set_model_params(
        self,
        param_values: np.array,
        start_idx: int,
        order_p: int,
        order_q: int,
        estimate_sigmas_initial: bool,
        estimate_errors_initial: bool,
        set_param_names: bool,
        set_param_priors: bool,
        y_tick_size: float,
        y_sigma: float,
    ) -> Tuple[int, List[str], List[Prior]]:
        param_names = []
        param_priors = []
        k = start_idx
        k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
        garch_sigma = val[0]
        if set_param_names:
            param_names.append("garch_sigma")
        if set_param_priors:
            param_priors.append(UniformInLogPrior(min_value=min(y_sigma / 100, y_tick_size / 5), max_value=y_sigma * 5))
        garch_beta = garch_alpha = np.zeros(0)
        if order_p > 0:
            k, garch_beta = get_params_values(values=param_values, start_idx=k, n_values=order_p)
            if set_param_names:
                param_names += [f"garch_beta_{i + 1}" for i in range(order_p)]
            if set_param_priors:
                param_priors.append(UniformPrior(min_value=0, max_value=1))
        if order_q > 0:
            k, garch_alpha = get_params_values(values=param_values, start_idx=k, n_values=order_q)
            if set_param_names:
                param_names += [f"garch_alpha_{i + 1}" for i in range(order_q)]
            if set_param_priors:
                param_priors.append(UniformPrior(min_value=0, max_value=1))
        garch_sigma_initial = self.sigma_initial
        if estimate_sigmas_initial:
            k, garch_sigma_initial = get_params_values(values=param_values, start_idx=k, n_values=order_p)
            if set_param_names:
                param_names += [f"garch_sigma_{i + 1}_initial" for i in range(order_p)]
            if set_param_priors:
                param_priors.append(
                    ZeroUnionUniformInLogPrior(
                        zero_prior_probability=Constants.zero_prior_probability_for_sigmas.value, non_zero_min_value=min(y_sigma / 10, y_tick_size / 5), max_value=y_sigma * 10
                    )
                )
        garch_error_initial = self.error_initial
        if estimate_errors_initial:
            k, garch_error_initial = get_params_values(values=param_values, start_idx=k, n_values=order_q)
            if set_param_names:
                param_names += [f"garch_error_{i + 1}_initial" for i in range(order_q)]
            if set_param_priors:
                param_priors.append(
                    ZeroUnionUniformInLogPrior(
                        zero_prior_probability=Constants.zero_prior_probability_for_sigmas.value, non_zero_min_value=min(y_sigma / 10, y_tick_size / 5), max_value=y_sigma * 10
                    )
                )
        self._change_params(
            order_p=order_p,
            order_q=order_q,
            w=garch_sigma**2,
            beta=garch_beta,
            alpha=garch_alpha,
            sigma_initial=garch_sigma_initial,
            error_initial=garch_error_initial,
        )
        return k, param_names, param_priors
