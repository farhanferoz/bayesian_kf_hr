from enum import Enum
import numpy as np


class Constants(Enum):
    zero_prior_probability_for_sigmas = 0.1
    ou_mean_reversion_min_half_life_sec = np.log(2)
    ou_mean_reversion_target_stdev = 1.0
    infinity = 1e90
