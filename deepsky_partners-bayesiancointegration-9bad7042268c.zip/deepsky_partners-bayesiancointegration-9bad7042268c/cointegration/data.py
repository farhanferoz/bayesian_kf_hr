import numpy as np
from typing import Optional


class Data:
    def __init__(
        self,
        y: np.array,
        x: np.ndarray,
        times: np.array,
        n_start: int,
        y_tick_size: float = 1.0,
        y_point_value: float = 1.0,
        x_point_value: Optional[np.array] = None,
        shift_x_to_equalize_y_and_x: bool = False,
        scale_x_to_equalize_y_and_x: bool = False,
    ):
        self.y_orig = np.copy(y)
        self.x_orig = np.copy(x)
        self.times_orig = times

        self.n_start = n_start
        self.y = np.copy(y[n_start:])
        self.x = np.copy(x[:, n_start:])
        self.times = times[n_start:]
        self.dt = self._calculate_dt(get_median=False)
        self.dt_median = self._calculate_dt(get_median=True)
        self.y_tick_size = y_tick_size
        self.y_point_value = y_point_value
        self.x_point_value = np.ones(self.x.shape[0]) if x_point_value is None else x_point_value
        self.shift_x_to_equalize_y_and_x = shift_x_to_equalize_y_and_x
        self.scale_x_to_equalize_y_and_x = scale_x_to_equalize_y_and_x

        self.n_x = self.x.shape[0]
        self.n_time = len(self.times)
        assert self.x.shape[1] == self.n_time
        assert len(self.y) == self.n_time
        assert len(self.x_point_value) == self.n_x

        # both shift_x_to_equalize_y_and_x and scale_x_to_equalize_y_and_x can't be true
        assert not (self.shift_x_to_equalize_y_and_x and self.scale_x_to_equalize_y_and_x)

        self.non_scaled_non_shifted_y = np.copy(y[n_start:])
        self.non_scaled_non_shifted_x = np.copy(x[:, n_start:])

        self.x_delta = np.zeros(self.n_x)
        if self.shift_x_to_equalize_y_and_x:
            self.x_delta = self.y[0] - self.x[:, 0]
            self.shift_x(x=self.x, reverse=False)

        self.x_scale = np.zeros(self.n_x)
        if self.scale_x_to_equalize_y_and_x:
            self.x_scale = self.y[0] / self.x[:, 0]
            self.scale_x(x=self.x, reverse=False)

        self.y_sigma = 0
        self.y_div_x_sigma = np.zeros(self.n_x)
        self._calculate_sigmas_before_n_start()

    def _calculate_dt(self, get_median: bool) -> float:
        times_diff = np.diff(self.times)
        if get_median:
            dt = np.median(times_diff)
        else:
            times_diff_unique = np.unique(times_diff)
            dt = times_diff_unique[0] if len(times_diff_unique) == 1 else np.nan
        return dt

    @staticmethod
    def _shift_time_series(time_series: np.array, delta: float, reverse: bool) -> np.array:
        return time_series + (-1 if reverse else 1) * delta

    def shift_x(self, x: np.ndarray, reverse: bool) -> None:
        assert x.shape[0] == self.n_x
        for i in range(self.n_x):
            x[i, :] = self._shift_time_series(time_series=x[i, :], delta=self.x_delta[i], reverse=reverse)

    @staticmethod
    def _scale_time_series(time_series: np.array, scale: float, reverse: bool) -> np.array:
        return time_series * ((1 / scale) if reverse else scale)

    def scale_x(self, x: np.ndarray, reverse: bool) -> None:
        assert x.shape[0] == self.n_x
        for i in range(self.n_x):
            x[i, :] = self._scale_time_series(time_series=x[i, :], scale=self.x_scale[i], reverse=reverse)

    def _calculate_sigmas_before_n_start(self) -> None:
        assert self.n_start > 1
        self.y_sigma = np.std(self.y_orig[: self.n_start])
        for i in range(self.n_x):
            self.y_div_x_sigma[i] = np.std(
                np.divide(self.y_orig[: self.n_start], self._shift_time_series(time_series=self.x_orig[i, : self.n_start], delta=self.x_delta[i], reverse=False))
            )
