import abc
import numpy as np
from enum import Enum
from typing import List, Tuple, Any, Optional

from cointegration.constants import Constants
from optimisers.priors import Prior, NormalPrior, UniformPrior, ZeroUnionUniformInLogPrior, UniformInLogPrior, ReflectedUniformInLogPrior


class ResidualModelId(Enum):
    ORNSTEIN_UHLENBECK = ("OU", 1, 1, 0, 0)
    SIMPLE_COINTEGRATION = ("SC", 1, 0, 0, 0)
    GARCH00 = ("G00", 0, 0, 0, 0)
    GARCH11 = ("G11", 0, 0, 1, 1)

    def __init__(self, label: str, n_state_params: int, n_non_state_non_sigma_params: int, garch_order_p: int, garch_order_q: int):
        self.label = label
        self.n_state_params = n_state_params
        self.n_non_state_non_sigma_params = n_non_state_non_sigma_params
        self.garch_order_p = garch_order_p
        self.garch_order_q = garch_order_q


def get_params_values(values: np.array, start_idx: int, n_values: int) -> Tuple[int, np.array]:
    return start_idx + n_values, values[start_idx : start_idx + n_values]


def get_rate_from_half_life(half_life: float) -> float:
    return np.log(2) / half_life


class ResidualModel(metaclass=abc.ABCMeta):
    def __init__(self, residual_model_id: ResidualModelId):
        self.residual_model_id = residual_model_id
        self.white_noise_sigma = np.nan
        self.initial_error = 0.0

    @staticmethod
    def _set_white_noise_sigma_prior(y_sigma: float, y_tick_size: float) -> Prior:
        return UniformInLogPrior(min_value=min(y_sigma / 100, y_tick_size / 5), max_value=y_sigma * 5)

    @abc.abstractmethod
    def change_params(self, values: np.array) -> None:
        raise NotImplementedError()

    @abc.abstractmethod
    def is_active(self) -> bool:
        raise NotImplementedError()

    @abc.abstractmethod
    def get_sigmas(self, for_initial: bool) -> np.array:
        raise NotImplementedError()

    @abc.abstractmethod
    def get_initial_parameter_values(self) -> np.array:
        raise NotImplementedError()

    @staticmethod
    def get_state_param_names() -> List[str]:
        raise NotImplementedError()

    @abc.abstractmethod
    def get_observation_matrix(self, last_error: float, dt: float) -> np.array:
        raise NotImplementedError()

    @abc.abstractmethod
    def get_noise_sigma(self, last_noise_sigma: Optional[float], last_error: Optional[float], dt: float) -> float:
        raise NotImplementedError()

    @abc.abstractmethod
    def get_error_mean(self, last_error: float, dt: float) -> float:
        raise NotImplementedError()

    @abc.abstractmethod
    def extract_and_set_model_params(
        self,
        param_values: np.array,
        start_idx: int,
        estimate_residual_model_non_state_non_sigma_params: bool,
        kf_estimate_non_beta_state_params_initial: bool,
        kf_estimate_non_beta_state_params_sigmas_initial: bool,
        is_model_static: bool,
        set_param_names: bool,
        set_param_priors: bool,
        y_tick_size: float,
        y_sigma: float,
        additional_info: List[Any],
    ) -> Tuple[int, List[str], List[Prior]]:
        raise NotImplementedError()


class OrnsteinUhlenbeck(ResidualModel):
    def __init__(
        self,
        white_noise_sigma: float,
        mean_reversion_rate_transition_sigma: float,
        mean_reversion_rate_initial_sigma: float,
        mean_reversion_rate_initial: float = 0.0,
        mean_reversion_target: float = 0.0,
    ):
        super().__init__(residual_model_id=ResidualModelId.ORNSTEIN_UHLENBECK)
        self.mean_reversion_rate_transition_sigma = np.nan
        self.mean_reversion_rate_initial_sigma = np.nan
        self.mean_reversion_rate_initial = np.nan
        self.mean_reversion_target = np.nan
        self.bias_transition_sigma = 0.0
        self.bias_initial_sigma = 0.0
        self.bias_initial = 1.0
        self.observation_matrix = np.zeros((1, 2))
        self.change_params([white_noise_sigma, mean_reversion_rate_transition_sigma, mean_reversion_rate_initial_sigma, mean_reversion_rate_initial, mean_reversion_target])

    def change_params(self, values: np.array) -> None:
        assert len(values) == 5
        if not np.isnan(values[0]):
            self.white_noise_sigma = values[0]
        if not np.isnan(values[1]):
            self.mean_reversion_rate_transition_sigma = values[1]
        if not np.isnan(values[2]):
            self.mean_reversion_rate_initial_sigma = values[2]
        if not np.isnan(values[3]):
            self.mean_reversion_rate_initial = values[3]
        if not np.isnan(values[4]):
            self.mean_reversion_target = values[4]
        self.observation_matrix = np.zeros((1, 2))

    def is_active(self) -> bool:
        return not (
            (self.mean_reversion_rate_initial == 1)
            and (self.mean_reversion_target == 0)
            and (self.mean_reversion_rate_transition_sigma == 0)
            and (self.mean_reversion_rate_initial_sigma == 0)
        )

    def get_sigmas(self, for_initial: bool) -> np.array:
        sigmas = [self.mean_reversion_rate_initial_sigma, self.bias_initial_sigma] if for_initial else [self.mean_reversion_rate_transition_sigma, self.bias_transition_sigma]
        return np.array(sigmas)

    def get_initial_parameter_values(self) -> np.array:
        return np.array([self.mean_reversion_rate_initial, self.bias_initial])

    @staticmethod
    def get_state_param_names() -> List[str]:
        return ["mean_reversion_rate", "constant"]

    def get_observation_matrix(self, last_error: float, dt: float) -> np.array:
        self.observation_matrix[0, 0] = (self.mean_reversion_target - last_error) * dt
        self.observation_matrix[0, 1] = last_error
        return self.observation_matrix

    def get_noise_sigma(self, last_noise_sigma: Optional[float], last_error: Optional[float], dt: float) -> float:
        return np.sqrt(dt) * self.white_noise_sigma

    def get_error_mean(self, last_error: float, dt: float) -> float:
        return last_error + self.mean_reversion_rate_initial * (self.mean_reversion_target - last_error) * dt

    def extract_and_set_model_params(
        self,
        param_values: np.array,
        start_idx: int,
        estimate_residual_model_non_state_non_sigma_params: bool,
        kf_estimate_non_beta_state_params_initial: bool,
        kf_estimate_non_beta_state_params_sigmas_initial: bool,
        is_model_static: bool,
        set_param_names: bool,
        set_param_priors: bool,
        y_tick_size: float,
        y_sigma: float,
        additional_info: List[Any],
    ) -> Tuple[int, List[str], List[Prior]]:
        mean_reversion_target_sigma = additional_info[0]
        ou_mean_reversion_max_half_life_sec = additional_info[1]

        param_names = []
        param_priors = []
        mean_reversion_rate_transition_sigma = mean_reversion_rate_initial_sigma = mean_reversion_rate_initial = mean_reversion_target = np.nan
        k = start_idx
        k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
        white_noise_sigma = val[0]
        if set_param_names:
            param_names.append("white_noise_sigma")
        if set_param_priors:
            param_priors.append(self._set_white_noise_sigma_prior(y_sigma=y_sigma, y_tick_size=y_tick_size))
        if estimate_residual_model_non_state_non_sigma_params:
            k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
            mean_reversion_target = val[0]
            if set_param_names:
                param_names.append("mean_reversion_target")
            if set_param_priors:
                param_priors.append(NormalPrior(mu=0, sigma=mean_reversion_target_sigma))
        if kf_estimate_non_beta_state_params_initial:
            k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
            mean_reversion_rate_initial = val[0]
            if set_param_names:
                param_names.append("mean_reversion_rate_initial")
            if set_param_priors:
                param_priors.append(
                    UniformInLogPrior(
                        min_value=get_rate_from_half_life(half_life=ou_mean_reversion_max_half_life_sec),
                        max_value=get_rate_from_half_life(half_life=Constants.ou_mean_reversion_min_half_life_sec.value),
                    )
                )
        if not is_model_static:
            zero_prior_probability = Constants.zero_prior_probability_for_sigmas.value
            if kf_estimate_non_beta_state_params_sigmas_initial:
                k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
                mean_reversion_rate_initial_sigma = val[0]
                if set_param_names:
                    param_names.append("mean_reversion_rate_initial_sigma")
                if set_param_priors:
                    param_priors.append(
                        ZeroUnionUniformInLogPrior(
                            zero_prior_probability=zero_prior_probability,
                            non_zero_min_value=get_rate_from_half_life(half_life=ou_mean_reversion_max_half_life_sec) * 0.1,
                            max_value=get_rate_from_half_life(half_life=Constants.ou_mean_reversion_min_half_life_sec.value) * 0.1,
                        )
                    )
            k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
            mean_reversion_rate_transition_sigma = val[0]
            if set_param_names:
                param_names.append("mean_reversion_rate_transition_sigma")
            if set_param_priors:
                param_priors.append(
                    ZeroUnionUniformInLogPrior(
                        zero_prior_probability=zero_prior_probability,
                        non_zero_min_value=get_rate_from_half_life(half_life=ou_mean_reversion_max_half_life_sec) * 0.1,
                        max_value=get_rate_from_half_life(half_life=Constants.ou_mean_reversion_min_half_life_sec.value) * 0.1,
                    )
                )
        self.change_params(
            values=np.array([white_noise_sigma, mean_reversion_rate_transition_sigma, mean_reversion_rate_initial_sigma, mean_reversion_rate_initial, mean_reversion_target])
        )
        return k, param_names, param_priors


class SimpleCointegration(ResidualModel):
    def __init__(self, white_noise_sigma: float, phi_transition_sigma: float, phi_initial_sigma: float, phi_initial: float = 0.0):
        super().__init__(residual_model_id=ResidualModelId.SIMPLE_COINTEGRATION)
        self.phi_transition_sigma = np.nan
        self.phi_initial_sigma = np.nan
        self.phi_initial = np.nan
        self.change_params([white_noise_sigma, phi_transition_sigma, phi_initial_sigma, phi_initial])
        self.observation_matrix = np.zeros((1, 1))

    def change_params(self, values: np.array) -> None:
        assert len(values) == 4
        if not np.isnan(values[0]):
            self.white_noise_sigma = values[0]
        if not np.isnan(values[1]):
            self.phi_transition_sigma = values[1]
        if not np.isnan(values[2]):
            self.phi_initial_sigma = values[2]
        if not np.isnan(values[3]):
            self.phi_initial = values[3]

    def is_active(self) -> bool:
        return (self.phi_initial != 0) or (self.phi_transition_sigma > 0) or (self.phi_initial_sigma > 0)

    def get_sigmas(self, for_initial: bool) -> np.array:
        return np.array([self.phi_initial_sigma] if for_initial else [self.phi_transition_sigma])

    def get_initial_parameter_values(self) -> np.array:
        return np.array([self.phi_initial])

    @staticmethod
    def get_state_param_names() -> List[str]:
        return ["phi"]

    def get_observation_matrix(self, last_error: float, dt: float) -> np.array:
        self.observation_matrix[0, 0] = last_error
        return self.observation_matrix

    def get_noise_sigma(self, last_noise_sigma: Optional[float], last_error: Optional[float], dt: float) -> float:
        return np.sqrt(dt) * self.white_noise_sigma

    def get_error_mean(self, last_error: float, dt: float) -> float:
        return self.phi_initial * last_error * dt

    def extract_and_set_model_params(
        self,
        param_values: np.array,
        start_idx: int,
        estimate_residual_model_non_state_non_sigma_params: bool,
        kf_estimate_non_beta_state_params_initial: bool,
        kf_estimate_non_beta_state_params_sigmas_initial: bool,
        is_model_static: bool,
        set_param_names: bool,
        set_param_priors: bool,
        y_tick_size: float,
        y_sigma: float,
        additional_info: List[Any],
    ) -> Tuple[int, List[str], List[Prior]]:
        param_names = []
        param_priors = []
        phi_initial = phi_sigma_initial = phi_transition_sigma = np.nan
        k = start_idx
        k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
        white_noise_sigma = val[0]
        if set_param_names:
            param_names.append("white_noise_sigma")
        if set_param_priors:
            param_priors.append(self._set_white_noise_sigma_prior(y_sigma=y_sigma, y_tick_size=y_tick_size))
        if kf_estimate_non_beta_state_params_initial:
            k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
            phi_initial = val[0]
            if set_param_names:
                param_names.append("phi_initial")
            if set_param_priors:
                param_priors.append(ReflectedUniformInLogPrior(min_value=0, max_value=1))
        if not is_model_static:
            zero_prior_probability = Constants.zero_prior_probability_for_sigmas.value
            if kf_estimate_non_beta_state_params_sigmas_initial:
                k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
                phi_sigma_initial = val[0]
                if set_param_names:
                    param_names.append("phi_sigma_initial")
                if set_param_priors:
                    param_priors.append(ZeroUnionUniformInLogPrior(zero_prior_probability=zero_prior_probability, non_zero_min_value=1e-5, max_value=0.5))
            k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
            phi_transition_sigma = val[0]
            if set_param_names:
                param_names.append("phi_transition_sigma")
            if set_param_priors:
                param_priors.append(ZeroUnionUniformInLogPrior(zero_prior_probability=zero_prior_probability, non_zero_min_value=1e-5, max_value=0.5))
        self.change_params(values=np.array([white_noise_sigma, phi_transition_sigma, phi_sigma_initial, phi_initial]))
        return k, param_names, param_priors


class Garch(ResidualModel):
    def __init__(
        self,
        residual_model_id: ResidualModelId,
        white_noise_sigma: float,
        beta: Optional[np.array] = None,
        alpha: Optional[np.array] = None,
        estimate_sigmas_initial: bool = False,
        estimate_errors_initial: bool = False,
        sigmas_initial: Optional[np.array] = None,
        errors_initial: Optional[np.array] = None,
    ):
        super().__init__(residual_model_id=residual_model_id)
        # order for the moving average part
        self.order_p = self.residual_model_id.garch_order_p
        assert self.order_p >= 0
        # order for the autoregressive part
        self.order_q = self.residual_model_id.garch_order_q
        assert self.order_q >= 0
        # square root of the intercept term (white noise sigma)
        self.white_noise_sigma = 0.0
        # moving average coefficients, should be of size order_p
        self.betas = np.zeros(self.order_p)
        # autoregressive coefficients, should be of size order_q
        self.alphas = np.zeros(self.order_q)
        # whether to estimate initial sigmas
        self.estimate_sigmas_initial = estimate_sigmas_initial
        # whether to estimate initial errors
        self.estimate_errors_initial = estimate_errors_initial
        # first p sigmas for the moving average part, should be of size order_p
        self.sigmas_initial = np.zeros(self.order_p)
        # first q errors for the autoregressive part, should be of size order_p
        self.errors_initial = np.zeros(self.order_q)

        # current p sigmas for the moving average part, should be of size order_p
        self.errors: Optional[np.array] = None
        # current q errors for the autoregressive part, should be of size order_p
        self.sigmas: Optional[np.array] = None

        self.n_values = 1 + 2 * (self.order_p + self.order_q)
        self.change_params(values=self._combine_params(white_noise_sigma=white_noise_sigma, beta=beta, alpha=alpha, sigma_initial=sigmas_initial, error_initial=errors_initial))

    def _combine_params(self, white_noise_sigma: float, beta: np.array, alpha: np.array, sigma_initial: np.array, error_initial: np.array) -> np.array:
        values = np.zeros(self.n_values)
        k = 0
        values[k] = white_noise_sigma
        k += 1
        values[k : k + self.order_p] = np.zeros(self.order_p) if beta is None else beta
        k += self.order_p
        values[k : k + self.order_q] = np.zeros(self.order_q) if alpha is None else alpha
        k += self.order_q
        values[k : k + self.order_p] = np.zeros(self.order_p) if sigma_initial is None else sigma_initial
        k += self.order_p
        values[k : k + self.order_q] = np.zeros(self.order_q) if error_initial is None else error_initial
        return values

    @staticmethod
    def _create_arr(order: int, current_vals: np.array, initial_vals: np.array) -> np.array:
        if len(current_vals) >= order:
            arr = current_vals[len(current_vals) - order :]
        else:
            arr = np.zeros(order)
            n = order - len(current_vals)
            arr[:n] = initial_vals[order - n]
            arr[n:] = current_vals
        return arr

    def _calculate_variance(self, dt: float) -> float:
        variance = (self.white_noise_sigma**2) * dt
        if self.order_p > 0:
            variance += np.dot(self.betas, np.square(self.sigmas))
        if self.order_q > 0:
            variance += np.dot(self.alphas, np.square(self.errors))
        return variance

    def change_params(self, values: np.array) -> None:
        assert len(values) == self.n_values
        k = 0
        self.white_noise_sigma = values[k]
        assert self.white_noise_sigma >= 0
        k += 1
        self.betas = values[k : k + self.order_p]
        k += self.order_p
        self.alphas = values[k : k + self.order_q]
        k += self.order_q
        self.sigmas_initial = values[k : k + self.order_p]
        k += self.order_p
        self.errors_initial = values[k : k + self.order_q]
        self.errors = np.copy(self.errors_initial)
        self.sigmas = np.copy(self.sigmas_initial)
        if self.order_q > 0:
            self.initial_error = self.errors_initial[-1]
        assert np.all(self.sigmas_initial >= 0)

    def is_active(self) -> bool:
        return (self.order_p > 0) or (self.order_q > 0)

    def get_sigmas(self, for_initial: bool) -> np.array:
        return np.zeros(0)

    def get_initial_parameter_values(self) -> np.array:
        return np.zeros(0)

    @staticmethod
    def get_state_param_names() -> List[str]:
        return []

    def get_observation_matrix(self, last_error: float, dt: float) -> np.array:
        return np.zeros((1, 0))

    def get_noise_sigma(self, last_noise_sigma: Optional[float], last_error: Optional[float], dt: float) -> float:
        if (self.order_p > 0) and (last_noise_sigma is not None):
            if self.order_p > 1:
                self.sigmas[:-1] = self.sigmas[1:]
            self.sigmas[-1] = last_noise_sigma
        if (self.order_q > 0) and (last_error is not None):
            if self.order_q > 1:
                self.errors[:-1] = self.errors[1:]
            self.errors[-1] = last_error
        return np.sqrt(self._calculate_variance(dt=dt))

    def get_error_mean(self, last_error: float, dt: float) -> float:
        return 0.0

    def extract_and_set_model_params(
        self,
        param_values: np.array,
        start_idx: int,
        estimate_residual_model_non_state_non_sigma_params: bool,
        kf_estimate_non_beta_state_params_initial: bool,
        kf_estimate_non_beta_state_params_sigmas_initial: bool,
        is_model_static: bool,
        set_param_names: bool,
        set_param_priors: bool,
        y_tick_size: float,
        y_sigma: float,
        additional_info: List[Any],
    ) -> Tuple[int, List[str], List[Prior]]:
        param_names = []
        param_priors = []
        k = start_idx
        k, val = get_params_values(values=param_values, start_idx=k, n_values=1)
        garch_sigma = val[0]
        if set_param_names:
            param_names.append("white_noise_sigma")
        if set_param_priors:
            param_priors.append(UniformInLogPrior(min_value=min(y_sigma / 100, y_tick_size / 5), max_value=y_sigma * 5))
        garch_beta = garch_alpha = np.zeros(0)
        if self.order_p > 0:
            k, garch_beta = get_params_values(values=param_values, start_idx=k, n_values=self.order_p)
            if set_param_names:
                param_names += [f"garch_beta_{i + 1}" for i in range(self.order_p)]
            if set_param_priors:
                param_priors.append(UniformPrior(min_value=0, max_value=1))
        if self.order_q > 0:
            k, garch_alpha = get_params_values(values=param_values, start_idx=k, n_values=self.order_q)
            if set_param_names:
                param_names += [f"garch_alpha_{i + 1}" for i in range(self.order_q)]
            if set_param_priors:
                param_priors.append(UniformPrior(min_value=0, max_value=1))
        garch_sigma_initial = self.sigmas_initial
        if self.estimate_sigmas_initial:
            k, garch_sigma_initial = get_params_values(values=param_values, start_idx=k, n_values=self.order_p)
            if set_param_names:
                param_names += [f"garch_sigma_{i + 1}_initial" for i in range(self.order_p)]
            if set_param_priors:
                param_priors.append(
                    ZeroUnionUniformInLogPrior(
                        zero_prior_probability=Constants.zero_prior_probability_for_sigmas.value, non_zero_min_value=min(y_sigma / 10, y_tick_size / 5), max_value=y_sigma * 10
                    )
                )
        garch_error_initial = self.errors_initial
        if self.estimate_errors_initial:
            k, garch_error_initial = get_params_values(values=param_values, start_idx=k, n_values=self.order_q)
            if set_param_names:
                param_names += [f"garch_error_{i + 1}_initial" for i in range(self.order_q)]
            if set_param_priors:
                param_priors.append(
                    ZeroUnionUniformInLogPrior(
                        zero_prior_probability=Constants.zero_prior_probability_for_sigmas.value, non_zero_min_value=min(y_sigma / 10, y_tick_size / 5), max_value=y_sigma * 10
                    )
                )
        self.change_params(
            values=self._combine_params(white_noise_sigma=garch_sigma, beta=garch_beta, alpha=garch_alpha, sigma_initial=garch_sigma_initial, error_initial=garch_error_initial)
        )
        return k, param_names, param_priors
