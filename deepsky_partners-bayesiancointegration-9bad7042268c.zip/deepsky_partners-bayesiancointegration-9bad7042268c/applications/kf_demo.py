import numpy as np
import pandas as pd
from time import time

from cointegration.data import Data
from cointegration.kalman_filter_cointegration import KalmanFilterCointegration
from cointegration.residual_models import SimpleCointegration, OrnsteinUhlenbeck, Garch, ResidualModelId
from cointegration.simulation import get_time_series_label, Columns


def run_on_white_noise_simulation() -> None:
    white_noise_sigma = 1.0
    n_time = 100000
    y = np.random.normal(loc=30, scale=0.1, size=n_time)
    x = np.random.normal(100, scale=0.1, size=(1, n_time))
    residual_model_sc = SimpleCointegration(white_noise_sigma=white_noise_sigma, phi_transition_sigma=1, phi_initial_sigma=1)
    residual_model_ou = OrnsteinUhlenbeck(white_noise_sigma=white_noise_sigma, mean_reversion_rate_transition_sigma=1, mean_reversion_rate_initial_sigma=1)
    tstart = time()
    kalman_filter_with_cointegration = KalmanFilterCointegration(
        data=Data(y=y, x=x, times=np.arange(n_time), n_start=100, scale_x_to_equalize_y_and_x=True),
        residual_model=residual_model_sc,
        beta_transition_sigmas=np.ones(2),
    )
    kalman_filter_with_cointegration.apply()
    print(time() - tstart)
    print(kalman_filter_with_cointegration.loglike)


def run_on_cointegration_simulation() -> None:
    param_values = [0, 1, 0.1]
    simulation_file = r"../data/simulation/data_OU.csv"
    df = pd.read_csv(simulation_file)
    white_noise_sigma = param_values[2]
    # residual_model_ou = OrnsteinUhlenbeck(
    #     white_noise_sigma=white_noise_sigma, mean_reversion_rate_transition_sigma=0, mean_reversion_rate_initial_sigma=0, mean_reversion_rate_initial=param_values[6]
    # )
    # residual_model_sc = SimpleCointegration(white_noise_sigma=white_noise_sigma, phi_transition_sigma=0, phi_initial_sigma=0)
    residual_model_garch = Garch(
        residual_model_id=ResidualModelId.GARCH00, white_noise_sigma=white_noise_sigma, beta=np.zeros(0), alpha=np.zeros(0), sigmas_initial=None, errors_initial=None
    )
    tstart = time()
    kalman_filter_with_cointegration = KalmanFilterCointegration(
        data=Data(
            y=df[get_time_series_label(time_series_id=1)].values,
            x=df[get_time_series_label(time_series_id=2)].values.reshape((1, len(df))),
            times=df[Columns.timestamp.value].values,
            n_start=100,
            scale_x_to_equalize_y_and_x=True,
        ),
        residual_model=residual_model_garch,
        beta_initial_values=np.array(param_values[:2]),
        beta_initial_sigmas=np.zeros(2),
        beta_transition_sigmas=np.zeros(2),
    )
    kalman_filter_with_cointegration.apply()
    print(time() - tstart)
    print(kalman_filter_with_cointegration.objective_function_value)


if __name__ == "__main__":
    np.random.seed(1)
    run_on_cointegration_simulation()
