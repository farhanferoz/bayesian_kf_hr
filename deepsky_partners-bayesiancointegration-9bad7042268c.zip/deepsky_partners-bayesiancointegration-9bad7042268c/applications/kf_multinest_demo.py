from time import time
import pandas as pd
import numpy as np

from cointegration.kalman_filter_cointegration import Data, ObjectiveFunction
from cointegration.model_specifications import ModelSpecifications, ModelType
from cointegration.residual_models import ResidualModelId
from cointegration.simulation import get_time_series_label, Columns
from optimisers.multinest import MultiNest
from optimisers.optimiser import BestParameterSelectionCriterion


def main():
    simulation_file = r"../data/simulation/data_OU.csv"
    model_type = ModelType.DYNAMIC_HEDGE_RATIOS_WITH_GARCH11
    objective_function = ObjectiveFunction.UNWEIGHTED_PNL
    best_parameter_selection_criterion = BestParameterSelectionCriterion.BEST_FIT

    residual_model_non_state_non_sigma_params = None
    if model_type.residual_model_id == ResidualModelId.ORNSTEIN_UHLENBECK:
        residual_model_non_state_non_sigma_params = np.array([0.0])
    df = pd.read_csv(simulation_file)
    data = Data(
        y=df[get_time_series_label(time_series_id=1)].values,
        x=df[get_time_series_label(time_series_id=2)].values.reshape((1, len(df))),
        times=df[Columns.timestamp.value].values,
        n_start=100,
        scale_x_to_equalize_y_and_x=True,
    )

    model_specifications = ModelSpecifications(
        data=data,
        model_type=model_type,
        objective_function=objective_function,
        kf_betas_initial=None,
        kf_non_beta_state_params_initial=None,
        kf_beta_sigmas_initial=None,
        kf_non_beta_state_param_sigmas_initial=None,
        residual_model_non_state_non_sigma_params=residual_model_non_state_non_sigma_params,
        garch_sigmas_initial=None,
        garch_errors_initial=None,
        guess_initial_state_params_and_sigmas=False,
        guess_initial_garch_sigmas_and_errors=False,
    )

    optimiser = MultiNest(
        best_parameter_selection_criterion=best_parameter_selection_criterion,
        model_specifications=model_specifications,
        outputfiles_basename=f"../data/chains/{model_type.label}_OBJ_{objective_function.label}_SELCRI_{best_parameter_selection_criterion.value}",
        resume=True,
        use_all_params_for_mode_separation=True,
    )
    optimiser.optimise()


if __name__ == "__main__":
    main()
